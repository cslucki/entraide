| Paramètre                          | DeepSeek R1 Qwen3 8B   | Qwen3.5 9B                                    | Pourquoi                                                              |
| ---------------------------------- | ---------------------- | --------------------------------------------- | --------------------------------------------------------------------- |
| ***Longueur de contexte***         | *`16384`*              | *`16384`*                                     | *Excellent équilibre vitesse / mémoire*                               |
| ***Déchargement GPU***             | *`Max` / `36 couches`* | *`Max`*                                       | *Exploite pleinement votre RTX 4070 12 Go*                            |
| ***CPU Thread Pool Size***         | *`6`*                  | *<mark style="background:#fff88f">`6`</mark>* | *<mark style="background:#fff88f">Bon équilibre pour i7-7700K</mark>* |
| **Taille du lot d’évaluation**     | `512`                  | `512`                                         | Très bon débit                                                        |
| **Max Concurrent Predictions**     | `1`                    | `1`                                           | Évite les ralentissements inutiles                                    |
| **Unified KV Cache**               | `ON`                   | `ON`                                          | Optimise mémoire et performances                                      |
| **Offload KV Cache to GPU Memory** | `ON`                   | `ON`                                          | Important pour rapidité                                               |
| **Garder le modèle en mémoire**    | `ON`                   | `ON`                                          | Chargement instantané                                                 |
| **Essayer mmap()**                 | `ON`                   | `ON`                                          | Réduit usage RAM                                                      |
| **Attention Flash**                | `ON`                   | `ON`                                          | Gain énorme de vitesse                                                |
| **Base fréquence RoPE**            | `OFF`                  | `OFF`                                         | Inutile ici                                                           |
| **Échelle fréquence RoPE**         | `OFF`                  | `OFF`                                         | Inutile ici                                                           |
| **K Cache Quantization**           | `OFF`                  | `OFF`                                         | Garder qualité maximale                                               |
| **V Cache Quantization**           | `OFF`                  | `OFF`                                         | Garder qualité maximale                                               |
| **Structured Output**              | `OFF`                  | `OFF`                                         | Sauf JSON/API strict                                                  |
| **Speculative Decoding**           | `OFF`                  | `OFF`                                         | Commencer simple/stable                                               |
| **Temperature**                    | `0.15`                 | `0.2`                                         | DeepSeek plus créatif, Qwen plus discipliné                           |
| **Top P**                          | `0.9`                  | `0.9`                                         | Bon équilibre précision/créativité                                    |
| **Top K**                          | `40`                   | `40`                                          | Valeur stable                                                         |
| **Min P**                          | `0.05`                 | `0.05`                                        | Très bon filtre                                                       |
| **Repeat Penalty**                 | `1.1`                  | `1.05`                                        | Évite répétitions                                                     |
| **Limiter longueur réponse**       | `OFF`                  | `OFF`                                         | Laisser le modèle répondre librement                                  |
| **Débordement de contexte**        | `Tronquer le milieu`   | `Tronquer le milieu`                          | Le plus stable                                                        |
| **Chaînes d’arrêt**                | vide                   | vide                                          | Pas nécessaire                                                        |
| **Graine fixe**                    | `OFF`                  | `OFF`                                         | Réponses naturelles                                                   |

# Rôle conseillé de chaque modèle

|Modèle|Usage idéal|
|---|---|
|DeepSeek DeepSeek R1 Qwen3 8B|Brainstorming, génération, exploration, architecture complexe|
|Qwen Qwen3.5 9B|Code quotidien, MCP, Laravel, agents, réponses précises|

# Message système recommandé (les deux modèles)

```txt
Tu es un assistant technique senior spécialisé dans :

- Laravel
- architecture logicielle
- agents IA
- MCP (Model Context Protocol)
- automatisation
- workflows IA
- analyse documentaire
- génération de scripts
- debugging

Règles importantes :

- Utilise les outils MCP quand ils sont disponibles.
- Lis les fichiers avant de répondre.
- Ne fais pas de suppositions inutiles.
- Privilégie les réponses concrètes et exécutables.
- Raisonne étape par étape.
- Quand tu proposes du code :
  - privilégie simplicité et maintenabilité
  - évite la complexité inutile
  - explique les impacts techniques
- Si une information manque, indique précisément ce qu’il faut vérifier.
- Évite le blabla inutile.
```