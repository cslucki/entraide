for branch in $(git branch --format='%(refname:short)'); do
  echo ""
  echo "BRANCH: $branch"
  git ls-tree -r --name-only "$branch" | grep "^ai/"
done
