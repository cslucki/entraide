#!/bin/bash

echo "======================================"
echo " SEARCHING AGENTS.md ACROSS BRANCHES "
echo "======================================"

for branch in $(git branch --format='%(refname:short)'); do
  echo ""
  echo "======================================"
  echo "BRANCH: $branch"
  echo "======================================"

  git show "$branch:AGENTS.md" 2>/dev/null | head -40 || echo "No AGENTS.md"
done
