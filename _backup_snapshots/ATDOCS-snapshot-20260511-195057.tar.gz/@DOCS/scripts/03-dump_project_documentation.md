# Project Documentation Dump

Generated on: Sat May  9 11:12:45 CEST 2026

Project root: `/home/cyril/claude-code/sites/test.laravel`

---


---

## CLAUDE.md

```markdown
# Entraide — AI Development Guide

This file is the main entrypoint for AI agents working on the project.

---

# Project Overview

BouclePro.com is a French multi-tenant peer-to-peer service exchange platform built with Laravel.

Users:
- publish services
- exchange points
- communicate through messaging
- interact inside isolated communities

The platform is entirely in French.

---

# Core Principles

This project prioritizes:

- tenant isolation
- business integrity
- maintainability
- predictable behavior
- explicit logic
- safe incremental refactors

Critical systems must remain stable:
- transactions
- point ledger
- tenant scopes
- policies
- messaging

---

# Mandatory Task Discipline

MANDATORY TASK UPDATE BEFORE COMMIT

Before ANY commit or push, agents MUST:
- update the task file
- update progress log
- update tests section
- update review notes
- update handoff if ownership changed

Commits without task updates are considered invalid workflow.

---

# AI Operating System

This repository uses a multi-agent orchestration system.

Agents must read:

- `AGENTS.md`

before starting any task.

Tasks are stored inside:

```text
TODO/
```

Each task is:
- persistent
- auditable
- multi-agent compatible
- handoff-compatible

The task file is the source of truth.

---

# Development Environment

Read:

```text
ai/environment.md
```

This file contains:
- WSL environment
- network configuration
- Playwright/browser access
- production environment
- database differences
- installed tooling
- standard commands

---

# Architecture Documentation

Read:

```text
ai/context/
```

Important files:
- architecture.md
- multi-tenant.md
- business-rules.md
- testing-strategy.md
- development-philosophy.md

---

# Workflows

Read:

```text
ai/workflows/
```

Important workflows:
- debugging.md
- livewire-debug.md
- review-process.md
- tenant-safety.md

---

# Tooling

Read:

```text
ai/tooling/
```

Installed tools include:
- batcat
- rg
- fzf
- lazygit
- tmux

Agents should prefer these tools when available.

Examples:
- use `rg` instead of `grep`
- use `batcat` instead of `cat`

---

# Prompts

Specialized prompts are stored inside:

```text
ai/prompts/
```

Examples:
- architect.md
- performance.md
- reviewer.md
- security.md
- ux.md

---

# Task Workflow

Before starting work:

1. read AGENTS.md
2. inspect existing tasks
3. lock the task
4. update task metadata
5. create/update branch
6. log all actions

---

# Git Rules

- never push directly to main
- use one branch per task
- keep commits focused
- inspect git diff before commit
- avoid unrelated modifications

Branch example:

```text
TASK-051-navbar-livewire-fix
```

---

# Frontend Rules

Never assume frontend behavior without validation.

Always inspect:
- browser behavior
- DOM state
- console errors
- responsive layout
- Livewire requests
- Alpine synchronization

Browser tooling and Playwright are strongly encouraged.

---

# Playwright QA System

The project includes an agentic Playwright QA system for browser testing.

**Documentation:** `ai/playwright/README.md`

**Quick Start:**
```bash
npx playwright test                    # Run all tests
npx playwright test --ui             # UI mode for debugging
npx playwright show-report ai/playwright/reports/html
```

**Helpers Available:**
```javascript
import { loginAsMember, login, logout } from '../../ai/playwright/helpers/auth.js';
import { captureScreenshot } from '../../ai/playwright/helpers/screenshot.js';
import { setupConsoleLogging } from '../../ai/playwright/helpers/console.js';
```

**Test Users for local testing:**
See .env for mor details about the test users.

**Artifacts Location:**
- Screenshots: `ai/playwright/screenshots/`
- Traces: `ai/playwright/test-results/`
- Videos: `ai/playwright/test-results/`
- Reports: `ai/playwright/reports/html/`

---

# Backend Rules

Before modifying:
- transactions
- point systems
- tenant scopes
- policies
- APIs

Always:
1. inspect architecture
2. inspect related models
3. inspect tests
4. validate side effects

---

# Testing Rules

Critical domains require validation:
- tenant isolation
- transactions
- points ledger
- policies
- APIs
- Livewire flows

Prefer:
- feature tests
- integration tests
- business-flow tests

---

# Important Rules

Never:
- bypass tenant isolation
- remove protections without validation
- perform uncontrolled rewrites
- modify unrelated systems
- ignore task logging
- hide architectural side effects

---

# Final Philosophy

Think before coding.

Inspect before modifying.

Validate before merging.

Prefer small safe changes over large rewrites.

```


---

## AGENTS.md

```markdown
# Entraide — Multi-Agent Operating System

This file defines the global multi-agent workflow used by all AI agents working on the project.

Technical architecture, environment and Laravel conventions are documented inside:

- `CLAUDE.md`
- `ai/environment.md`
- `ai/context/*`
- `ai/workflows/*`
- `ai/tooling/*`

---

# Core Philosophy

The system is:

- task-centric
- multi-agent
- persistent
- auditable
- handoff-friendly

The task is the source of truth, not the agent.

---
# MANDATORY TASK LIFECYCLE

TASK files are the operational memory of the project.

Agents MUST:
- read the TASK file before any implementation
- continuously update the TASK file during execution
- append progress after each major step
- document architecture decisions
- document discoveries
- document executed tests
- document blockers/errors
- update TASK before commit

A TASK file is NOT optional documentation.
---

# Mandatory Task Discipline

MANDATORY TASK UPDATE BEFORE COMMIT

Before ANY commit or push, agents MUST:
- update the task file
- update progress log
- update tests section
- update review notes
- update handoff if ownership changed

Commits without task updates are considered invalid workflow.

---

# What Is An Agent

An agent is an AI system capable of:

- reading tasks
- modifying code
- running tests
- updating task logs
- coordinating through handoffs
- respecting architectural rules

Agents may include:

- GLM
- JULES
- CLAUDE
- GEMINI
- CODEX
- OPENCODE
- DEEPSEEK

---

# Source Of Truth

Each task is represented by a single markdown file inside:

```text
TODO/
```

Example:

```text
TODO/TASK-051-navbar-livewire-fix.md
```

This file is the single source of truth for:

- status
- ownership
- progress
- handoffs
- tests
- reviews
- timestamps

---

# One Task = One Branch

Each task uses exactly one git branch.

Example:

```text
TASK-051-navbar-livewire-fix
```

Do not create one branch per agent.

The task owns the branch.

---

# Task Lifecycle

Tasks follow this lifecycle:

```text
TODO
IN_PROGRESS
BLOCKED
TESTING
IN_REVIEW
DONE
MERGED
ARCHIVED
```

---

# Task Ownership

Each task may contain:

- one owner
- multiple contributors

Example:

```yaml
owner: GLM

contributors:
  - JULES
  - CLAUDE
```

---

# Lock System

Before modifying a task:

1. lock the task
2. update task status
3. update timestamps
4. document intended actions

Example:

```yaml
lock:
  status: LOCKED
  agent: GLM
  since: 2026-05-07 16:42:11 Europe/Paris
```

Agents must not work simultaneously on the same files without coordination.

---

# Handoff System

When an agent stops working:

- update task log
- describe current state
- list modified files
- list pending actions
- unlock the task

This allows another agent to continue safely.

---

# Mandatory Logging

Agents must continuously update:

- progress logs
- tests
- handoffs
- blockers
- review notes
- modified files

All operations must include timestamps.

Example:

```text
2026-05-07 16:42:11 Europe/Paris
```

---

# Machine-Readable Format

Each task begins with YAML metadata.

Example:

```yaml
---
task_id: TASK-051
status: IN_PROGRESS
owner: GLM
contributors:
  - JULES
branch: TASK-051-navbar-livewire-fix
---
```

This format allows future orchestration and automation.

---

# Testing Rules

Before review:

- run relevant tests
- inspect browser behavior
- inspect console errors
- validate responsive behavior
- validate tenant safety
- verify architectural consistency

---

# Browser & Playwright Rules

Agents are encouraged to use browser tooling for:

- screenshots
- responsive testing
- DOM inspection
- Livewire debugging
- Alpine.js validation
- console inspection

Do not assume frontend behavior without browser validation.

---

# Forbidden Actions

Agents must never:

- push directly to main
- bypass tenant isolation
- remove protections without justification
- overwrite another agent's work
- ignore task logging
- modify unrelated systems
- bypass architectural rules

---

# Review Philosophy

Prefer:

- small safe changes
- explicit logic
- maintainability
- predictable behavior
- incremental refactors

Avoid:

- architecture drift
- hidden side effects
- uncontrolled rewrites
- premature abstractions

---

# Important Rule

The task file must always reflect the real current state of the work.

The task log is mandatory.

No hidden work.

```


---

## ai/agents/agents-list.md

```markdown
# Agents List

## Primary Agents

| Agent | Role | Priority |
|---|---|---|
| GLM | Main orchestrator, primary coder, task coordination | PRIMARY |
| JULES | Frontend specialist, Blade, Alpine.js, UI implementation | PRIMARY |
| CLAUDE | Architecture, backend, reviews, advanced reasoning | SECONDARY |

---

## Secondary Agents

| Agent | Role |
|---|---|
| GEMINI | Analysis, reviews, research, alternative reasoning |
| CODEX | Advanced coding assistance |
| OPENCODE | Future usage |
| DEEPSEEK | Alternative reasoning and coding support |

---

# Multi-Agent Rules

- Multiple agents may contribute to the same task
- One task = one source of truth
- One task = one git branch
- Handoffs are mandatory between agents
- Agents must update task logs continuously
- All actions must be timestamped using Europe/Paris timezone

---

# Task Ownership

Each task may contain:

- one primary owner
- multiple contributors

Example:

```yaml
owner: GLM

contributors:
  - JULES
  - CLAUDE
```

---

# Lock System

Before modifying a task:

1. lock the task
2. update task status
3. update timestamps
4. log intended actions

Agents must not work simultaneously on the same files without explicit coordination.

---

# Handoff Rules

When an agent stops working:

- update task status
- write current state
- list modified files
- list pending actions
- unlock task

This allows another agent to continue safely.

---

# Branch Strategy

One git branch per task.

Example:

TASK-051-navbar-livewire-fix

Do not create one branch per agent.

The task is the source of truth, not the agent.

---

# Review Rules

Before review:

- tests must run
- browser validation must be completed
- console errors must be checked
- tenant safety must be verified
- task log must be updated

---

# Forbidden Actions

Agents must never:

- push directly to main
- bypass tenant isolation
- remove tests without justification
- modify unrelated systems
- ignore task logging
- overwrite another agent's work
```


---

## ai/context/architecture.md

```markdown
# Architecture Overview

## Project Type

Entraide is a multi-tenant peer-to-peer service exchange platform built with Laravel.

Users:
- publish services
- exchange points
- communicate through messaging
- perform transactions
- interact inside isolated communities

The application is entirely in French.

---

# Core Architectural Principles

## Multi-Tenant First

The platform is community-based.

Each tenant/community:
- has its own slug
- has isolated data
- must remain isolated at all times

Tenant isolation is a critical architectural rule.

Main tenant mechanism:
- `community_id`
- `ResolveCommunity` middleware
- `BelongsToTenantScope`

---

## UUID Architecture

All primary keys use UUIDs.

Rules:
- never use incremental IDs
- always use `uuid('id')->primary()`
- preserve UUID consistency across relations

---

## Thin Controllers

Controllers should:
- validate requests
- authorize actions
- delegate business logic

Avoid:
- large business logic inside controllers
- duplicated logic

---

## Business Integrity

Critical business flows:
- points system
- transactions
- tenant isolation
- messaging
- reviews

These systems must remain stable and coherent.

---

# Main Domains

## Services

Users publish services:
- title
- description
- category
- skills
- tags
- delivery mode
- points cost

Services belong to communities.

---

## Transactions

Transactions follow a strict state machine:

pending → accepted → buyer_done → completed
        ↘ refused
pending/accepted → cancelled

Rules:
- financial consistency is critical
- operations must be atomic
- point ledger must remain append-only

---

## Messaging

Messaging uses:
- Livewire
- polling
- unread tracking
- system messages

Performance must remain controlled.

---

## Reviews

Reviews:
- are linked to completed transactions
- affect user ratings
- must remain consistent with transaction state

---

## Admin System

Admin area manages:
- users
- services
- transactions
- reports
- communities
- settings

Admin actions must never bypass:
- policies
- tenant integrity
- business consistency

---

# Frontend Architecture

Frontend stack:
- Blade
- Alpine.js
- Tailwind CSS
- Livewire

Rules:
- keep Livewire components lightweight
- avoid unnecessary polling
- validate UI behavior with browser tools

---

# API Architecture

API uses:
- Laravel Sanctum
- token authentication
- REST endpoints

Rules:
- authorization is mandatory
- tenant isolation applies to APIs
- never expose cross-tenant data

---

# Testing Philosophy

Critical domains require tests:
- policies
- transactions
- points system
- tenant isolation
- API authorization

Prefer:
- integration tests
- business-flow tests
- policy tests

---

# Architectural Safety Rules

Before modifying:
- tenant logic
- transactions
- point system
- policies
- scopes

Always:
1. inspect architecture
2. inspect related models
3. inspect policies
4. inspect routes
5. inspect tests
6. validate side effects

---

# Preferred Development Philosophy

Prefer:
- maintainability
- explicitness
- predictable behavior
- small safe refactors

Avoid:
- unnecessary abstractions
- hidden magic
- uncontrolled refactors
- breaking tenant isolation
```


---

## ai/context/browser-tools.md

```markdown
# Browser & Visual Tooling

Use browser and visual tools for:

- Livewire debugging
- DOM inspection
- browser console inspection
- screenshots
- responsive validation
- Alpine.js inspection
- Tailwind verification

---

# Preferred Workflow

1. inspect UI
2. inspect DOM
3. inspect console
4. inspect network behavior
5. inspect Livewire requests
6. only then modify code

---

# Validation Rules

Do not assume:
- frontend behavior
- Alpine state
- Livewire synchronization
- responsive correctness

without browser verification.
```


---

## ai/context/business-rules.md

```markdown
# Business Rules

## Critical Rules

- Point ledger is append-only
- Financial operations must be atomic
- UUID architecture must never be broken
- Transaction state machine must remain valid
- Policies are mandatory for protected actions

## Transaction State Machine

pending → accepted → buyer_done → completed
        ↘ refused
pending/accepted → cancelled

## Points System

- New user receives welcome bonus
- Point ledger is immutable
- Balance updates must be transactional

## Safety Rules

Never modify:
- tenant integrity
- transaction consistency
- point ledger integrity
without explicit verification.
```


---

## ai/context/development-philosophy.md

```markdown
# Development Philosophy

## Core Principles

Prefer:
- maintainability
- explicitness
- predictable behavior
- minimal safe changes
- readability
- business integrity

Avoid:
- premature abstraction
- unnecessary complexity
- magic behavior
- uncontrolled refactors
- hidden side effects

---

# Laravel Philosophy

Prefer:
- Laravel conventions
- thin controllers
- reusable services
- policy-driven authorization
- explicit validation

Avoid:
- duplicated business logic
- massive controllers
- unsafe static helpers
- tightly coupled components

---

# Refactoring Rules

Before refactoring:
1. understand business implications
2. inspect architecture
3. inspect tests
4. minimize blast radius

Prefer small incremental refactors.

---

# AI Agent Philosophy

Agents should:
- think before coding
- inspect before modifying
- validate before merging
- preserve architectural consistency

Never optimize blindly.
```


---

## ai/context/multi-tenant.md

```markdown
# Multi-Tenant Rules

## Tenant Isolation

- All tenant-scoped models must respect BelongsToTenantScope
- Community isolation is mandatory
- Never bypass tenant filtering manually
- Community slug resolution must remain stable

## Critical Models

Tenant-sensitive models:
- User
- Service
- ServiceRequest
- Transaction

## Validation Rules

Before modifying tenant logic:
1. Verify routes
2. Verify policies
3. Verify scopes
4. Verify database consistency
5. Verify UI behavior
```


---

## ai/context/testing-strategy.md

```markdown
# Testing Strategy

## Critical Domains

The following systems require strong testing coverage:

- tenant isolation
- transactions
- point ledger
- policies
- APIs
- Livewire flows

---

# Preferred Tests

Prefer:
- feature tests
- integration tests
- business-flow tests
- policy tests

Avoid:
- brittle implementation-specific tests

---

# Validation Workflow

Before merge:
1. run relevant tests
2. validate tenant safety
3. validate transaction consistency
4. validate UI behavior
5. inspect logs if needed

---

# AI Testing Philosophy

Agents should:
- add tests for critical business logic
- preserve existing tests
- avoid removing protections
- validate edge cases

Critical business systems should never be modified without validation.
```


---

## ai/decisions/ADR-001-task-centric-architecture.md

```markdown
# ADR-001 — Task-Centric Multi-Agent Architecture

## Status

Accepted

---

# Context

The project uses multiple AI agents:

- GLM
- JULES
- CLAUDE
- GEMINI
- others in the future

Originally, the system used one TODO file per agent.

Example:

- TODO_GLM.md
- TODO_JULES.md

This approach created limitations:
- fragmented state
- difficult handoffs
- duplicated tracking
- weak auditability
- poor scalability

---

# Decision

The system now uses a task-centric architecture.

Each task is represented by:

```text
TODO/TASK-XXX-description.md
```

The task file is the single source of truth.

Tasks:
- support multiple agents
- support handoffs
- support locks
- support auditability
- support future orchestration

---

# Consequences

Benefits:
- persistent shared memory
- safer multi-agent collaboration
- improved auditability
- easier future automation
- better scalability

Tradeoffs:
- stricter workflow discipline required
- mandatory task logging
- mandatory lock/handoff workflow

---

# Future Direction

This architecture is designed to support:

- orchestration systems
- dashboards
- automated reviews
- analytics
- task automation
- future AI coordination systems

```


---

## ai/environment.md

```markdown
# Development Environment

## Local Environment

Project runs inside WSL2 Ubuntu.

### WSL Host

- Host: WSL2
- OS: Ubuntu
- Local Linux IP: 127.0.0.1

### Windows Host Access

Windows accesses Laravel through:

- Windows IP: 172.27.130.89
- Local URL:
  https://test.laravel/dashboard

This URL must be used for:
- Playwright
- browser automation
- screenshots
- responsive validation
- UI testing

Do not use localhost from Windows browser tooling.

---

# Production Environment

Production product:
- BouclePro.com

Production infrastructure:
- Laravel Cloud

Production URL:
https://bouclepro.com

---

# Database

Local:
- SQLite

Production:
- PostgreSQL

Agents must always verify SQL compatibility.

Avoid:
- SQLite-only queries
- PostgreSQL-incompatible syntax

---

# Stack Versions

- PHP 8.4
- Laravel 13.7
- Livewire 3
- Alpine.js
- Tailwind CSS v4
- Node 22
- Vite

---

# Installed Terminal Tools

Preferred tools installed in WSL:

- batcat
- rg
- fzf
- lazygit
- git
- tmux

Agents should prefer these tools over basic alternatives.

Examples:
- use `batcat` instead of `cat`
- use `rg` instead of `grep`

---

# Browser & Playwright Rules

Agents are encouraged to use browser tooling for:

- screenshots
- UI debugging
- responsive testing
- console inspection
- Livewire inspection
- Alpine.js validation

Preferred workflow:
1. inspect UI
2. inspect console
3. inspect network
4. capture screenshots
5. only then modify code

## Playwright QA System

**Documentation:** `ai/playwright/README.md`

**Run tests:**
```bash
npx playwright test                    # All tests
npx playwright test --ui             # UI mode
npx playwright test --headed           # Watch browser
npx playwright show-report ai/playwright/reports/html
```

**Browser projects configured:**
- Chromium (Desktop Chrome)
- Firefox
- WebKit (Safari)
- Mobile Chrome

**WebKit is intentionally enabled in Playwright projects to improve cross-browser frontend quality and Safari compatibility.**

**Test users:**
see .env for login details

**Device profiles available:**
- Desktop: 1280x720, 1920x1080
- Tablet: 768x1024, 1024x768
- Mobile: 375x667, 414x896


---

# Standard Commands

## Development

```bash
php artisan serve
npm run dev
```

## Tests

```bash
php artisan test
```

## Build

```bash
npm run build
```

---

# Git Workflow

- Main branch: main
- One branch per task
- Never commit directly to main
- Keep commits atomic and focused

Branch naming example:

TASK-051-navbar-livewire-fix

---


# HTTPS Local Development

Local development uses HTTPS with a local development certificate.

Playwright/browser automation must use:

```javascript
ignoreHTTPSErrors: true

---

# Important Rules

Before modifying frontend behavior:
- inspect visually
- inspect DOM
- inspect console
- inspect Livewire requests
- inspect Alpine state

Never assume UI behavior without browser validation.
```


---

## ai/orchestrator/README.md

```markdown
# Future Orchestrator

This directory is reserved for future orchestration systems.

Possible future features:
- task automation
- lock management
- task assignment
- dashboards
- analytics
- agent coordination
- automatic reviews
- task lifecycle automation

The current architecture is intentionally machine-readable to support future orchestration.

```


---

## ai/playwright/README.md

```markdown
# Playwright QA System

## Overview

Agentic Playwright QA system for BouclePro.com testing.

Supports realistic SaaS workflows:
- form automation
- file uploads
- JS console inspection
- screenshots
- video recording
- trace generation
- responsive validation

---

# Why WebKit Matters

WebKit (Safari engine) is intentionally enabled.

Goals:
- improve frontend robustness
- enforce standards-compliant CSS/JS
- detect browser-specific rendering issues
- validate iPhone/iPad compatibility
- force AI agents to produce more portable frontend code

The additional execution time is considered acceptable for the long-term quality benefits.

WebKit may require additional Linux dependencies under WSL2:
sudo npx playwright install-deps

---

## Quick Start

### Run all tests

```bash
npx playwright test
```

### Run single test file

```bash
npx playwright test tests/e2e/publish-article.spec.js
```

### Run with UI mode (for debugging)

```bash
npx playwright test --ui
```

### Run in headed mode (see browser)

```bash
npx playwright test --headed
```

---

## Reports

### Open HTML report

```bash
npx playwright show-report ai/playwright/reports/html
```

### View trace (after test failure)

```bash
npx playwright show-trace ai/playwright/test-results/trace-xxxx.zip
```

---

## Artifacts Location

| Type | Location |
|------|----------|
| Screenshots | `ai/playwright/screenshots/` |
| Videos | `ai/playwright/test-results/` |
| Traces | `ai/playwright/test-results/` |
| HTML reports | `ai/playwright/reports/html/` |
| JSON results | `ai/playwright/reports/results.json` |

---

## Architecture

```
ai/playwright/
├── config/         # Configuration files
├── devices/         # Device profiles
├── helpers/         # Reusable helpers
│   ├── auth.js      # Login/logout functions
│   ├── screenshot.js # Screenshot utilities
│   ├── console.js   # JS console logging
│   └── trace.js     # Trace utilities
├── users/           # Test user profiles
│   ├── admin.js
│   ├── member.js
│   └── cpme-member.js
├── scenarios/       # Business workflows
└── screenshots/     # Captured screenshots
```

---

## Helpers Usage

### Authentication

```javascript
import { loginAsMember, login, logout } from '../../ai/playwright/helpers/auth.js';

// Login as default member
await loginAsMember(page);

// Login with custom credentials
await login(page, 'email@example.com', 'password');

// Logout
await logout(page);
```

### Screenshots

```javascript
import { captureScreenshot, captureFailureScreenshot } from '../../ai/playwright/helpers/screenshot.js';

// Capture full-page screenshot
await captureScreenshot(page, 'dashboard-view');

// Capture on test failure
test.afterEach(async ({ page }, testInfo) => {
    if (testInfo.status !== 'passed') {
        await captureFailureScreenshot(page, testInfo);
    }
});
```

### Console Logging

```javascript
import { setupConsoleLogging, assertNoConsoleErrors } from '../../ai/playwright/helpers/console.js';

test.beforeEach(async ({ page }) => {
    setupConsoleLogging(page);
});

test.afterEach(async () => {
    assertNoConsoleErrors();
});
```

---

## Test Users

| Type | Email | Password | Location |
|------|-------|----------|----------|
| Admin (dev) | test@example.com | password | `users/admin.js` |
| Member (dev) | alice@example.com | password | `users/member.js` |
| CPME Member (dev) | alice@example.com | password | `users/cpme-member.js` |
| Demo users | *@bouclepro.com | demo2026 | DemoSeeder |

---

## Device Profiles

```javascript
import { desktopViewport, tabletViewport, mobileViewport } from '../../ai/playwright/devices/index.js';
```

### Available Devices

- **Desktop**: 1280x720, 1920x1080
- **Tablet**: 768x1024, 1024x768
- **Mobile**: 375x667, 414x896

---

## Test Structure

```javascript
import { test, expect } from '@playwright/test';
import { loginAsMember, captureScreenshot } from '../../ai/playwright/helpers/auth.js';

test.describe('Feature Name', () => {
    test.beforeEach(async ({ page }) => {
        await loginAsMember(page);
    });

    test('specific scenario', async ({ page }) => {
        // Arrange
        await page.goto('/route');

        // Act
        await page.fill('input[name="field"]', 'value');
        await page.click('button[type="submit"]');

        // Assert
        await expect(page).toHaveURL(/expected/);
        await captureScreenshot(page, 'result');
    });
});
```

---

## Best Practices

1. **Always login at test level** - use test.describe() with beforeEach
2. **Capture screenshots** - at key steps for debugging
3. **Check console errors** - use setupConsoleLogging
4. **Wait for network idle** - for async operations
5. **Use specific selectors** - prefer name attributes over CSS classes
6. **Validate URLs** - use `toHaveURL()` with regex

---

## Existing Scenarios

| Test | Description |
|------|-------------|
| smoke.spec.js | Basic navigation and dashboard checks |
| login-member.spec.js | Member login flow |
| publish-article.spec.js | Article creation and publishing |

---

## Debugging Tips

### Run single test in headed mode

```bash
npx playwright test -g "test name" --headed
```

### Run with inspector

```bash
npx playwright codegen https://test.laravel
```

### Check traces

```bash
npx playwright show-trace ai/playwright/test-results/trace-file.zip
```

```


---

## ai/prompts/architect.md

```markdown
You are a senior Laravel architect.

Your role:
- analyze architecture
- minimize technical debt
- preserve tenant isolation
- maintain transaction consistency
- improve maintainability
- detect architectural drift

Rules:
- respect UUID architecture
- preserve append-only point ledger
- preserve transaction state machine
- avoid unnecessary complexity
- prefer maintainable solutions

Use:
- rg for code search
- bat for file inspection
- fzf for navigation
```


---

## ai/prompts/performance.md

```markdown
You are a Laravel performance specialist.

Focus on:
- N+1 queries
- eager loading
- Livewire polling
- database efficiency
- caching opportunities
- unnecessary re-renders

Prefer scalable solutions.
```


---

## ai/prompts/reviewer.md

```markdown
You are a senior Laravel code reviewer.

Focus on:
- code quality
- security
- maintainability
- policy enforcement
- tenant isolation
- duplicated logic
- side effects

Review changes critically before approval.
```


---

## ai/prompts/security.md

```markdown
You are a Laravel security reviewer.

Focus on:
- policies
- authorization
- tenant leaks
- mass assignment
- Sanctum auth
- validation
- unsafe queries

Never assume tenant isolation is correct without verification.
```


---

## ai/prompts/ux.md

```markdown
You are a product and UX reviewer for a Laravel marketplace platform.

Focus on:
- user friction
- onboarding clarity
- transaction flow simplicity
- accessibility
- trust and transparency
- mobile usability

Prefer simple and intuitive flows.
```


---

## ai/tasks/templates/TASK_TEMPLATE.md

```markdown
---
task_id: TASK-050
title: Example Task

status: TODO

owner: null

contributors: []

branch: null

priority: MEDIUM

created_at: null
updated_at: null

labels: []

lock:
  status: UNLOCKED
  agent: null
  since: null

handoff: false

pr:
  status: NOT_READY
  url: null
---

# Objective

Describe the objective.

---

# Planned Actions

- [ ] inspect architecture
- [ ] inspect impacted files
- [ ] implement changes
- [ ] run tests
- [ ] validate UI

---
# Progress Log

# Handoffs

# Tests

- [ ] feature tests
- [ ] browser validation
- [ ] responsive validation
- [ ] console inspection
- [ ] tenant validation

---

# Test Results

Pending.

---

# Review Notes

Pending.
```


---

## ai/tooling/git-workflow.md

```markdown
# Development Philosophy

## Core Principles

Prefer:
- maintainability
- explicitness
- predictable behavior
- minimal safe changes
- readability
- business integrity

Avoid:
- premature abstraction
- unnecessary complexity
- magic behavior
- uncontrolled refactors
- hidden side effects

---

# Laravel Philosophy

Prefer:
- Laravel conventions
- thin controllers
- reusable services
- policy-driven authorization
- explicit validation

Avoid:
- duplicated business logic
- massive controllers
- unsafe static helpers
- tightly coupled components

---

# Refactoring Rules

Before refactoring:
1. understand business implications
2. inspect architecture
3. inspect tests
4. minimize blast radius

Prefer small incremental refactors.

---

# AI Agent Philosophy

Agents should:
- think before coding
- inspect before modifying
- validate before merging
- preserve architectural consistency

Never optimize blindly.
```


---

## ai/tooling/mcp-tools.md

```markdown
# MCP Tooling

## Browser & Visual Tools

Use browser/visual MCP tools for:
- Livewire debugging
- DOM inspection
- browser console inspection
- screenshots
- Tailwind verification

Do not assume UI behavior without browser verification.

## Filesystem MCP

Use Filesystem MCP for:
- architecture analysis
- project-wide inspection
- relationship discovery
- detecting duplicated logic

## SQLite MCP

Use SQLite MCP for:
- tenant verification
- transaction inspection
- relationship validation
- debugging business rules
```


---

## ai/tooling/terminal-tools.md

```markdown
# Terminal Tooling

## rg

Prefer `rg` over grep.

Use for:
- routes
- policies
- tenant logic
- transactions
- Livewire components

## bat

Prefer `bat` over `cat`.

Use for:
- logs
- PHP files
- Blade templates
- migrations

## fzf

Use for:
- fuzzy search
- navigation
- project exploration

## lazygit

Use for:
- branch management
- commit review
- merge inspection
```


---

## ai/workflows/debugging.md

```markdown
# Laravel Debugging Workflow

## Goal

Debug issues safely while preserving:
- tenant isolation
- transaction consistency
- business integrity
- UI consistency

Avoid blind fixes.

---

# Standard Debugging Process

## 1. Understand the Problem

Before modifying code:

- identify expected behavior
- identify actual behavior
- identify impacted domains
- identify tenant implications
- identify transaction implications

Never implement fixes before understanding the root cause.

---

## 2. Inspect Logs

Prefer:

```bash
bat storage/logs/laravel.log
```

Inspect:

* stack traces
* SQL errors
* authorization failures
* Livewire errors

---

## 3. Search Related Code

Prefer:

```bash
rg "keyword"
```

Inspect:

* controllers
* policies
* routes
* models
* Livewire components
* middleware

---

## 4. Inspect Architecture

Use Filesystem MCP when available.

Understand:

* related models
* tenant scope
* policy flow
* transaction flow
* component relationships

Avoid isolated fixes without architecture understanding.

---

## 5. Verify UI Behavior

Use browser/MCP tools when available.

Inspect:

* browser console
* DOM state
* Livewire requests
* Alpine.js behavior
* validation errors

Do not assume frontend behavior without verification.

---

## 6. Implement Minimal Safe Fix

Prefer:

* smallest safe modification
* explicit logic
* maintainable solutions

Avoid:

* large rewrites
* unrelated refactors
* hidden side effects

---

## 7. Validate

After modifications:

* run relevant tests
* inspect tenant safety
* inspect policies
* verify transaction consistency
* verify UI behavior

---

# Critical Rule

Never modify:

* tenant logic
* transaction logic
* point system
* policies

without complete understanding of side effects.

```


---

## ai/workflows/handoff.md

```markdown
# Agent Handoff Workflow

## Goal

Allow safe continuation of work between multiple AI agents.

The task file is the source of truth.

---

# When A Handoff Is Required

A handoff is required when:

- an agent reaches quota limits
- an agent stops working
- another agent takes over
- review is delegated
- debugging is delegated

---

# Mandatory Handoff Actions

Before stopping work, the agent must:

1. update task status
2. update timestamps
3. document current state
4. list modified files
5. describe remaining work
6. describe blockers if any
7. unlock the task

---

# Required Handoff Format

```markdown
# Handoff

Timestamp:
2026-05-07 18:42:11 Europe/Paris

Current Status:
IN_PROGRESS

Current Agent:
GLM

Next Recommended Agent:
JULES

Modified Files:
- resources/views/livewire/navbar.blade.php
- app/Livewire/Navbar.php

Completed Work:
- fixed duplicate refresh
- reduced polling frequency

Remaining Work:
- mobile responsive validation
- console inspection

Warnings:
- possible Alpine.js desynchronization
```

---

# Important Rules

Handoffs must be:
- explicit
- complete
- auditable

No hidden work.


```


---

## ai/workflows/livewire-debug.md

```markdown
# Livewire Debug Workflow

## Goal

Debug Livewire safely while preserving:
- UI responsiveness
- performance
- tenant safety
- predictable state

---

# Standard Workflow

## 1. Inspect Browser First

Use browser/MCP tools when available.

Inspect:
- console errors
- network requests
- Livewire payloads
- DOM state
- Alpine interactions

Do not assume UI behavior without browser verification.

---

## 2. Inspect Component Logic

Inspect:
- component properties
- computed state
- validation rules
- polling
- emitted events

Prefer:
- explicit state
- predictable updates

Avoid:
- hidden state mutations
- duplicated logic

---

# Polling Rules

Use polling carefully.

Avoid:
- unnecessary polling
- excessive refresh rates
- heavy database queries during polling

Keep Livewire components lightweight.

---

# Validation Workflow

Verify:
- validation errors
- loading states
- optimistic UI behavior
- Alpine synchronization

---

# Performance Rules

Inspect:
- N+1 queries
- repeated renders
- large payloads
- unnecessary eager loading

Prefer scalable UI behavior.

---

# Tenant Safety

Always verify:
- tenant filtering
- authenticated user consistency
- scoped queries
- policy enforcement

---

# Final Validation

Before merge:
- test UI manually
- inspect console
- verify responsive behavior
- verify tenant consistency
- run relevant tests

```


---

## ai/workflows/playwright-review.md

```markdown
Excellent 👍
Alors maintenant :

# on passe du “script qui marche”

à

# un vrai workflow QA agentique.

Et ça va devenir très puissant pour BouclePro.

---

# OBJECTIF MAINTENANT

Standardiser :

* screenshots
* conventions
* review UI
* debug visuel
* workflow agent → screenshot → correction.

---

# ÉTAPE 1 — créer une vraie TASK

Depuis `develop` :

```bash id="m8q2pk"
./ai/scripts/create-task.sh
```

Titre :

```text id="x4m7tv"
Setup Playwright review workflow
```

---

# ÉTAPE 2 — créer workflow markdown

Créer :

```text id="r5m1qx"
ai/workflows/playwright-review.md
```

---

# CONTENU RECOMMANDÉ

````md id="k2m8rv"
# Playwright Review Workflow

## Objective

Use Playwright for:
- screenshots
- UI validation
- responsive testing
- visual debugging
- multi-agent QA

---

# Screenshot Locations

Store screenshots in:

ai/screenshots/

---

# Naming Convention

Examples:

- homepage-desktop.png
- homepage-mobile.png
- dashboard-admin.png
- profile-page-mobile.png

---

# Standard Workflow

## 1. Launch Playwright

```bash
node ai/scripts/test-playwright.js
````

---

## 2. Capture screenshots

Store inside:

ai/screenshots/

---

## 3. Review results

Check:

* spacing
* overflow
* responsiveness
* dark mode
* console errors
* missing images
* broken layouts

---

## 4. Apply fixes

Agents should:

* inspect screenshots
* identify UI issues
* fix incrementally
* retest visually

---

# Responsive Targets

## Desktop

* 1440x900

## Tablet

* 768x1024

## Mobile

* 390x844

---

# Validation Checklist

* no broken layout
* no overflow
* no hidden buttons
* dark mode OK
* navigation OK
* images visible
* console clean

---

# Multi-Agent Usage

Playwright screenshots can be:

* generated by one agent
* reviewed by another
* validated by human reviewer

This creates a distributed QA workflow.

````

---

# ÉTAPE 3 — ajouter à TASK

Dans la nouvelle TASK :
- objectif
- progress log
- tests.

---

# ÉTAPE 4 — commit propre

```bash id="p7x1tw"
git add .

git commit -m "feat: add Playwright review workflow"

git push origin develop
````
```


---

## ai/workflows/playwright.md

```markdown
# Browser & Playwright Workflow

## Goal

Validate frontend behavior using browser tooling and Playwright.

Do not assume frontend behavior without browser validation.

---

# Use Cases

Playwright and browser tooling should be used for:

- screenshots
- responsive testing
- UI debugging
- console inspection
- Livewire validation
- Alpine.js validation
- navigation testing
- visual verification

---

# Browser Access

Local development URL:

```text
https://test.laravel/dashboard
```

Do not use localhost from Windows browser tooling.

---

# Preferred Validation Workflow

1. open browser
2. inspect UI
3. inspect console
4. inspect network requests
5. inspect Livewire requests
6. inspect Alpine state
7. capture screenshots
8. only then modify code

---

# Responsive Validation

Always validate:
- desktop
- tablet
- mobile

Important for:
- Livewire
- navigation
- Alpine.js
- modals
- dropdowns

---

# Console Inspection

Always inspect:
- JavaScript errors
- Livewire errors
- Alpine errors
- failed requests
- hydration issues

---

# Screenshot Rules

Screenshots may be stored inside:

```text
ai/screenshots/
```

Useful for:
- debugging
- reviews
- regressions
- handoffs

---


# Browser Tooling Compatibility

Different AI agents may use different browser automation systems.

Examples:
- Playwright npm
- embedded Chromium
- MCP browser tools
- sandbox browsers
- proprietary visual tooling

The important requirement is the workflow:

1. inspect UI
2. inspect console
3. inspect network
4. capture screenshots
5. validate responsive behavior
6. validate fixes visually

The exact tooling may vary depending on the agent.

---


# Important Rules

Never assume:
- responsive correctness
- Alpine synchronization
- Livewire synchronization
- visual consistency

without browser validation.

```


---

## ai/workflows/review-process.md

```markdown
# Review Process

## Goal

Review code changes critically before merge.

Focus on:
- maintainability
- business integrity
- tenant safety
- security
- performance
- architectural consistency

---

# Review Workflow

## 1. Inspect Git Diff

Prefer:
- small diffs
- focused changes
- isolated modifications

Avoid:
- unrelated rewrites
- formatting noise
- hidden side effects

---

## 2. Inspect Architecture Impact

Review:
- impacted domains
- policies
- routes
- transactions
- tenant implications
- Livewire implications

---

## 3. Verify Business Integrity

Critical systems:
- point ledger
- transactions
- tenant isolation
- messaging
- reviews

Must remain coherent after changes.

---

# Security Review

Inspect:
- authorization
- policies
- validation
- mass assignment
- unsafe queries
- tenant leaks

---

# Performance Review

Inspect:
- N+1 queries
- eager loading
- polling frequency
- query duplication
- unnecessary renders

---

# UI Review

Verify:
- browser behavior
- responsive layout
- validation states
- loading states
- console errors

Use browser tools when available.

---

# Testing Review

Verify:
- relevant tests exist
- tests still pass
- critical flows remain safe

Critical domains require tests.

---

# Merge Validation

Before merge:
- inspect final diff
- verify no secrets committed
- verify no unrelated files changed
- verify tenant consistency
- verify architectural consistency

---

# Review Philosophy

Prefer:
- maintainability
- explicitness
- predictable behavior
- small safe changes

Avoid:
- clever abstractions
- uncontrolled refactors
- architecture drift
```


---

## ai/workflows/task-lifecycle.md

```markdown
# Task Lifecycle

## Goal

Standardize task states across all agents.

---

## Mandatory Task Updates

Task files are the operational source of truth.

Agents MUST update the task file:
- before implementation
- after major progress
- before commit
- before push
- before handoff
- before marking task completed

Required sections:
- Progress Log
- Tests
- Review Notes
- updated_at

---

# Lifecycle

```text
TODO
IN_PROGRESS
BLOCKED
TESTING
IN_REVIEW
DONE
MERGED
ARCHIVED
```

---

# Status Definitions

## TODO

Task exists but work has not started.

---

## IN_PROGRESS

An agent is actively working on the task.

The task should normally be locked.

---

## BLOCKED

Work cannot continue.

Examples:
- missing information
- failing dependency
- quota limitation
- unresolved bug

Blockers must be documented.

---

## TESTING

Implementation is complete.

Validation is ongoing.

Examples:
- feature tests
- browser validation
- responsive checks
- Playwright testing

---

## IN_REVIEW

Task is ready for human or agent review.

---

## DONE

Implementation and validation are complete.

Waiting for merge.

---

## MERGED

Changes merged into target branch.

---

## ARCHIVED

Task is closed and archived.

---

# Important Rules

Task status must always reflect reality.

Agents must update:
- timestamps
- logs
- handoffs
- lock state

```


---

## ai/workflows/tenant-safety.md

```markdown
# Tenant Safety Workflow

## Goal

Preserve strict tenant isolation across the entire platform.

Tenant integrity is a critical architectural rule.

---

# Tenant Safety Rules

## Core Principle

A user must never access data from another community unless explicitly authorized.

---

# Verification Workflow

Before modifying tenant-related code:

1. inspect routes
2. inspect middleware
3. inspect policies
4. inspect scopes
5. inspect database queries
6. inspect Livewire behavior
7. inspect API responses

---

# Critical Components

Tenant-sensitive systems:

- User
- Service
- ServiceRequest
- Transaction
- Messaging
- Reviews
- Favorites

---

# Scope Rules

Tenant filtering should rely on:
- `BelongsToTenantScope`
- `ResolveCommunity`
- policies

Avoid:
- manual tenant filtering duplication
- bypassing scopes
- unsafe queries

---

# Dangerous Patterns

Avoid:

```php
withoutGlobalScopes()
```

unless explicitly justified and validated.

Avoid:

* raw queries without tenant validation
* manual joins bypassing scopes
* exposing foreign UUIDs

---

# Validation Rules

Always verify:

* authenticated user tenant
* route tenant slug
* policy tenant consistency
* database tenant consistency
* frontend tenant consistency

---

# API Safety

APIs must:

* respect tenant boundaries
* never expose cross-tenant data
* validate authenticated tenant access

---

# Final Validation

Before merge:

* verify UI
* verify policies
* verify database consistency
* verify no cross-tenant leaks


```


---

## docs/COMPONENT_LIBRARY.md

```markdown
TO DO
```


---

## docs/ENGINEERING_RULES.md

```markdown
# Additional UI & Product Engineering Rules

---

# Layout System

## Containers

Use consistent container widths.

Preferred max widths:

* Narrow reading content: `max-w-3xl`
* Standard app sections: `max-w-5xl`
* Wide dashboard sections: `max-w-7xl`

Avoid:

* full-width text blocks
* inconsistent margins
* random container sizing

---

## Vertical Rhythm

Spacing must follow a predictable rhythm.

Preferred spacing scale:

* 4
* 8
* 12
* 16
* 24
* 32
* 48
* 64

Avoid arbitrary spacing values.

---

# Section Design

Each section must answer ONE primary question.

Avoid:

* mixing multiple objectives
* multiple competing CTAs
* visually overloaded sections

Every section should have:

* clear title
* optional subtitle
* dominant action
* breathing space

---

# Empty States

Empty states are part of the UX.

They must:

* reassure users
* explain what to do next
* reduce friction

Avoid:

* sterile “No results”
* technical language
* dead-end screens

Preferred tone:

* calm
* encouraging
* actionable

---

# Loading States

Loading states should feel:

* fast
* subtle
* intentional

Prefer:

* skeleton loaders
* soft pulse effects
* progressive rendering

Avoid:

* spinners everywhere
* blocking overlays
* aggressive animations

---

# Animations

Animations are OPTIONAL.

If used:

* subtle
* fast
* purposeful

Avoid:

* bouncing
* elastic motion
* exaggerated transitions
* “AI futuristic” effects

Preferred transition duration:

* 150ms to 250ms

---

# Icons

Icons support comprehension.
They must not dominate the interface.

Rules:

* use sparingly
* consistent size
* avoid icon overload
* never rely only on icons without text

Preferred:

* Lucide icons
* outline style
* minimal usage

---

# Tables & Data

Tables must remain readable.

Rules:

* avoid excessive columns
* prioritize mobile readability
* use whitespace generously
* truncate intelligently

On mobile:

* prefer stacked layouts over horizontal overflow

---

# Dashboard Philosophy

Dashboards must NOT feel overwhelming.

Avoid:

* metric overload
* too many cards
* too many colors
* dense admin interfaces

Prioritize:

* one key insight
* progressive exploration
* simple hierarchy

---

# Admin Interfaces

Admin screens should still feel premium.

Avoid:

* old-school enterprise UI
* tiny text
* crowded tables
* checkbox overload

Admin ≠ ugly.

---

# Accessibility

Minimum accessibility rules:

* sufficient contrast
* visible focus states
* keyboard navigation support
* labels for all inputs
* touch-friendly mobile spacing

Minimum mobile tap target:

* 44x44px

---

# Performance Rules

Frontend performance is part of UX.

Avoid:

* unnecessary JS
* large UI libraries
* excessive Alpine watchers
* unnecessary re-renders

Prefer:

* Livewire-native patterns
* server-driven UI
* progressive enhancement

---

# Dependency Policy

Before adding any package:

You MUST explain:

* why it is needed
* why native Laravel/Livewire/Tailwind is insufficient
* frontend impact
* build impact
* maintenance cost

Prefer:

* native browser APIs
* Tailwind utilities
* Alpine minimalism

Avoid:

* UI kits
* animation frameworks
* heavy state managers

---

# Component Naming

Reusable components must have predictable names.

Preferred:

* PrimaryButton
* SecondaryButton
* SectionHeader
* EmptyState
* ConversationInput
* MobileDrawer

Avoid:

* vague naming
* duplicated components
* one-off variants

---

# Dark Mode Principles

Dark mode is NOT:

* “black mode”
* cyberpunk mode
* neon mode

Dark mode should:

* reduce eye fatigue
* preserve hierarchy
* remain elegant

Use:

* soft surfaces
* muted borders
* subtle separation

---

# AI Interaction Philosophy

AI interactions must:

* reduce friction
* simplify choices
* accelerate action

Avoid:

* fake chatbot personalities
* unnecessary conversational loops
* excessive prompts
* gimmicks

AI exists to help users DO things.

---

# Product Consistency Rule

When implementing a new feature:

DO NOT invent a new UI pattern if one already exists.

Before creating:

* button styles
* cards
* inputs
* dropdowns
* modals

Check existing components first.

Consistency is more important than originality.

---

# Validation Process

Before every PR submission:

Required:

* desktop screenshots
* mobile screenshots
* dark mode screenshots
* responsive verification
* Playwright validation

No feature is considered complete without visual validation.

---

# Final Principle

Simplicity scales.
Visual noise does not.

When uncertain:
remove complexity,
not clarity.

```


---

## docs/PRODUCT_PRINCIPLES.md

```markdown
# Engineering Workflow Rules

---

# Git Workflow

## Branch Strategy

Each feature MUST have its own branch.

Examples:

* `feature/ai-homepage`
* `feature/referral-system`
* `feature/notification-center`
* `feature/admin-ai`

Avoid:

* mixed-purpose branches
* unrelated commits
* direct commits to main

---

## Merge Strategy

Never merge directly into `main`.

Workflow:

1. Feature branch
2. Merge into `develop`
3. QA & validation
4. UI harmonization if needed
5. Merge `develop -> main`

---

## Commit Discipline

Commits must be:

* small
* focused
* understandable

Avoid:

* giant commits
* mixed frontend/backend changes without explanation
* “fix stuff” commit messages

Preferred commit style:

* `feat: add conversational homepage input`
* `fix: correct mobile notification spacing`
* `refactor: extract reusable conversation input component`

---

# Multi-Agent Coordination

This project is developed with multiple AI agents.

Therefore:

* avoid touching unrelated files
* avoid refactoring outside task scope
* document architectural decisions
* respect ownership boundaries

---

## Scope Protection

If working on:

* notifications

DO NOT modify:

* homepage
* admin AI
* referral system

Unless explicitly requested.

---

# Testing Rules

Every feature requires:

## Backend

* Feature tests
* Unit tests when needed

## Frontend

* Playwright validation
* mobile validation
* dark mode validation

---

# Screenshot Requirements

Every visual feature MUST provide:

* desktop screenshots
* mobile screenshots
* dark mode screenshots

Real screenshots only.
No mockups.

---

# Playwright Rules

Playwright is mandatory for:

* responsive validation
* navigation validation
* UI regression checks
* AI interaction validation

Capture:

* successful user flows
* empty states
* menu interactions
* conversational interactions

---

# Tailwind Rules

Prefer:

* reusable component extraction
* consistent spacing
* utility clarity

Avoid:

* giant unreadable class strings
* duplicated utility groups
* inconsistent spacing systems

---

# Livewire Rules

Prefer:

* small focused components
* server-driven interactions
* progressive enhancement

Avoid:

* giant Livewire components
* business logic inside Blade
* duplicated state handling

---

# Alpine.js Rules

Alpine should remain lightweight.

Use only for:

* dropdowns
* local interactions
* UI toggles
* small reactive behavior

Avoid:

* complex application state
* business logic
* excessive nested x-data

---

# AI Architecture Rules

AI logic must remain:

* configurable
* provider-agnostic
* prompt-driven

Avoid:

* hardcoded AI behavior
* prompt duplication
* AI logic spread everywhere

Preferred structure:

* providers
* factories
* prompt builders
* centralized settings

---

# Prompt Management

Prompts should be:

* editable
* versioned
* centralized

Avoid:

* hidden prompts in controllers
* inline giant prompt strings
* duplicated instructions

---

# Admin UX Rules

Admin tools should:

* expose control clearly
* remain readable
* avoid overwhelming complexity

Admin interfaces must still feel premium.

---

# Error Handling

Errors must:

* help users recover
* remain human-readable
* avoid technical jargon

Avoid:

* raw exception dumps
* cryptic validation messages

---

# Performance Rules

Prioritize:

* perceived speed
* reduced JS
* fast rendering
* minimal dependencies

Avoid:

* frontend bloat
* unnecessary polling
* excessive reactivity

---

# Security Rules

Never expose:

* API keys
* internal prompts
* provider secrets
* admin-only configuration

AI calls must remain server-side.

---

# Production Safety

Before final validation, always provide:

* composer changes
* npm changes
* migrations
* env changes
* queue requirements
* cache requirements

Deployment must remain predictable.

---

# Documentation Rules

Every major feature must document:

* architecture
* decisions
* limitations
* reusable components
* future extension points

---

# Product Philosophy

The product must feel:

* coherent
* intentional
* calm
* scalable

Not:

* improvised
* overloaded
* “AI-generated”

The user experience must always feel curated by humans.

```


---

## docs/UI_RULES.md

```markdown
# BouclePro UI Rules

## Philosophy

BouclePro must feel:

* calm
* intelligent
* conversational
* trustworthy
* lightweight
* premium
* human

The interface should reduce cognitive load and help users understand instantly what to do.

We optimize for:

* clarity
* onboarding speed
* readability
* simplicity
* consistency

NOT for:

* visual effects
* trendy animations
* dashboard overload
* “startup flashy UI”

---

# General Principles

## Mobile First

Always design mobile first.

Desktop is an expansion of mobile,
not the opposite.

Mobile interfaces must feel:

* lighter
* faster
* simpler
* less dense

---

## Conversational UX

The platform should feel conversational.

Users should feel:
“I can simply describe what I want.”

Avoid:

* excessive forms
* complex filters
* intimidating interfaces
* overloaded dashboards

---

# Visual Rules

## Whitespace

Whitespace is intentional.

Use generous spacing.

Never compress interfaces to “fit more”.

Prefer:

* breathing room
* visual rhythm
* separation between sections

---

## Typography

Typography hierarchy must be clear.

Rules:

* maximum 3 font sizes per section
* avoid tiny text
* avoid excessive bold
* prioritize readability

Preferred hierarchy:

* Title
* Subtitle
* Body
* Caption

Never create visual noise with typography.

---

## Colors

Use color sparingly.

Primary accent:

* BouclePro purple

Avoid:

* multiple accent colors
* neon effects
* saturated gradients
* strong shadows

Gradients allowed ONLY:

* hero sections
* subtle atmospheric backgrounds

---

## Borders & Radius

Standard radius:

* 16px cards
* 12px buttons
* 20px conversational inputs

Avoid:

* inconsistent radius
* sharp corners
* random rounding

---

## Shadows

Use subtle shadows only.

Goal:
depth, not decoration.

Avoid:

* floating/glowing cards
* glassmorphism overload
* hard shadows

---

# Buttons

## General Rules

Buttons must feel:

* obvious
* calm
* readable

Never:

* use ALL CAPS
* overload with icons
* use dark text on dark backgrounds

---

## CTA Hierarchy

Maximum:

* 1 dominant CTA per viewport
* 2 primary actions per section

Everything else should be secondary.

---

## Button Types

### Primary Button

Used for:

* publish
* continue
* validate
* submit

### Secondary Button

Used for:

* cancel
* back
* alternative actions

### Ghost Button

Used for:

* subtle contextual actions
* filters
* optional hints

---

# Inputs

## Conversational Inputs

AI-style inputs must:

* feel spacious
* support multiline
* contain send button INSIDE the input
* feel centered and calm

Avoid:

* tiny chat bubbles
* fake chatbot interfaces
* overcomplicated AI widgets

---

## Forms

Forms should:

* minimize friction
* minimize visible fields
* progressively disclose complexity

Avoid:

* long forms
* stacked dense inputs
* excessive validation messages

---

# Cards

Cards must:

* separate content clearly
* avoid unnecessary decoration
* prioritize readability

Avoid:

* dashboard-style density
* nested cards
* excessive borders

---

# Navigation

## Navbar

Navbar must remain:

* lightweight
* stable
* predictable

Avoid:

* crowded menus
* too many icons
* multiple CTA buttons

---

## Mobile Drawer

Mobile menu should follow:

* ChatGPT
* Gemini
* Linear simplicity

Bottom action:

* “Se connecter” button

Keep menu short and obvious.

---

# Notifications

Notifications should:

* feel calm
* feel informative
* avoid aggressive unread states

Unread indicators:

* subtle only

Avoid:

* bright badges everywhere
* noisy dropdowns

---

# Dark Mode

Dark mode should feel:

* elegant
* soft
* readable

Avoid:

* pure black
* high contrast neon
* glowing effects

Use:

* soft dark surfaces
* muted borders
* subtle depth

---

# Responsive Rules

Every new UI must be validated for:

* desktop
* tablet
* mobile
* dark mode

Playwright screenshots are mandatory before validation.

---

# Component Strategy

Prefer reusable components.

Avoid:

* duplicating Tailwind blocks
* creating one-off UI patterns
* inconsistent spacing systems

Create reusable:

* buttons
* cards
* section layouts
* conversational inputs
* mobile drawers

---

# AI UX Principles

AI should:

* simplify the platform
* reduce friction
* guide naturally

AI must NOT:

* overwhelm users
* simulate fake conversations
* add unnecessary complexity

The AI exists to help users act quickly.

---

# Final Product Goal

The product should feel:

* modern
* calm
* obvious
* human
* intelligent
* frictionless

Users should understand the platform in seconds,
without needing tutorials or onboarding flows.

```

