(/home/cyril/.claude/settings.json


{
  "env": {
    "ANTHROPIC_AUTH_TOKEN": "27911c4a024e443ca455e805e9bef521.4ypGgIOX5Ag5nq2u",
    "ANTHROPIC_BASE_URL": "https://api.z.ai/api/anthropic",
    "API_TIMEOUT_MS": "3000000",
    "CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC": "1"
  },
  "extraKnownMarketplaces": {
    "zai-coding-plugins": {
      "source": {
        "source": "directory",
        "path": "/home/cyril/.npm/_npx/2f024689b4d0d3b0/node_modules/@z_ai/coding-helper/zai-coding-plugins"
      }
    }
  },
  "theme": "dark",
  "verbose": true,
  "enabledPlugins": {
    "glm-plan-usage@zai-coding-plugins": true
  }
}
