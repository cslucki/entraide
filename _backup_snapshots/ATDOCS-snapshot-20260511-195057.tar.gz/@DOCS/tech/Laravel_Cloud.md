                                                                                                                                                            
  ---                                                                                                                                                           
  Option 1 — Via le Dashboard Laravel Cloud                                                                                                                     
  Laravel Cloud propose une interface pour voir les variables d'environnement, dont DATABASE_URL. Avec cette URL PostgreSQL, tu peux te connecter depuis        
  n'importe quel client graphique :                                                                                                                           
  - TablePlus (recommandé, gratuit)                                                                                                                             
  - pgAdmin                                                                                                                                                   
  - DBeaver                                                                                                                                                     
                                                                                                                                                              
  Tu copies l'URL depuis Environments → ton env → Variables, et tu la colles dans le client.                                                                    
                                                                                                                                                                
  ---                                                                                                                                                         
  Option 2 — Via le CLI Laravel Cloud                                                                                                                           
                                                                                                                                                              
  # Installer le CLI si pas encore fait                                                                                                                       
  composer global require laravel/cloud-cli                                                                                                                     
  
  # Se connecter                                                                                                                                                
  cloud login                                                                                                                                                 
                                                                                                                                                                
  # Ouvrir un tunnel vers la DB (si supporté)                                                                                                                   
  cloud db:tunnel                                                                                                                                             
                                                                                                                                                                
  Pas sûr que cloud db:tunnel existe encore — la fonctionnalité dépend de la version du CLI. Vérifie avec cloud help.                                           
                                                                                                                                                              
  ---                                                                                                                                                           
  Option 3 — php artisan tinker à distance                                                                                                                    
                                                                                                                                                                
  Si Laravel Cloud permet l'exécution de commandes Artisan depuis le dashboard ou le CLI :
  cloud artisan tinker                                                                                                                                          
  # ou                                                                                                                                                        
  cloud artisan db:show                                                                                                                                         
                                                                                                                                                              
  ---                                                                                                                                                           
  Option 4 — Dump SQL via Artisan (méthode fiable)
                                                                                                                                                                
  Tu pousses une route ou commande temporaire qui exporte les données en CSV/JSON, tu la déclenches, tu récupères le fichier.                                 
                                                                                                                                                                
  ---                                                                                                                                                         
  Ma recommandation pratique :                                                                                                                                  
                                                                                                                                                                
  1. Va dans le dashboard Laravel Cloud → ton projet → Variables d'environnement                                                                              
  2. Copie DATABASE_URL (format postgresql://user:password@host:port/dbname)                                                                                    
  3. Ouvre TablePlus, "New Connection from URL", colle l'URL                                                                                                    
  4. Tu peux naviguer, exporter en CSV ou faire un dump complet                                                                                                 
                                                                                                                                                                
  Tu veux que je t'aide à préparer quelque chose de spécifique (migration de prod vers local, backup, export CSV) ?   