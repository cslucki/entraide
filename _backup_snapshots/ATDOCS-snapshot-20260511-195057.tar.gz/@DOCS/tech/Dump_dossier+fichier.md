find ai -type f | sort | while read file; do
  echo ""
  echo "=============================="
  echo "FILE: $file"
  echo "=============================="
  cat "$file"
done > ai_dump.txt