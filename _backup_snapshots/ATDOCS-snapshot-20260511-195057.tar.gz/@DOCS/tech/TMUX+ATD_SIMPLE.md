```bash
# 1. Créer une session persistante
tmux new -s claude

# 2. Lancer Claude Code dans la session tmux :
claude

# 3.Détacher la session sans arrêter Claude
# Faire : CTRL+B puis D
# Cela laisse : tmux actif + * Claude actif

# 4. Vérifier les sessions tmux
tmux ls
# Exemple : claude: 1 windows (created Tue May 5 23:57:04 2026)

# 5. Revenir dans la session
tmux attach -t claude

# 6. Tuer complètement la session
tmux kill-session -t claude

# 7. Injecter un message dans Claude
tmux send-keys -t claude "Reprend" Enter
tmux send-keys -t claude "Continue les tâches restantes" Enter

echo 'tmux send-keys -t claude "Bonjour" Enter' | at now

echo 'tmux send-keys -t claude "Claude reprend en lisant le fichier /home/cyril/claude-code/sites/test.laravel/@DOCS/PROMPTS.md et prend les tâches qui restent à faire" Enter' | at now + 162 minutes


```



# 11. Tester atd

Test simple :

```bash
echo 'echo "ATD OK" >> /tmp/atd.log' | at now + 1 minute
```

Puis :

```bash
cat /tmp/atd.log
```

---




```

---

# 13. Important : syntaxe atd

Cette syntaxe peut échouer :

```bash
at now + 2 hours 42 minutes
```

Préférer :

```bash
at now + 162 minutes
```

---

# 14. Exemple avancé

```bash
echo 'tmux send-keys -t claude "Claude reprend en lisant le fichier /home/cyril/claude-code/sites/test.laravel/@DOCS/PROMPTS.md et prend les tâches qui restent à faire" Enter' | at now + 162 minutes
```

---

# 15. Vérifier les tâches planifiées

```bash
atq
```

Exemple :

```text
5 Wed May 6 02:41:00 2026 a cyril
```

---

# 16. Supprimer une tâche

```bash
atrm NUMERO
```

---

# 17. Méthode recommandée : script shell

Créer :

```bash
nano ~/resume-claude.sh
```

Contenu :

```bash
#!/bin/bash

tmux send-keys -t claude "Claude reprend en lisant le fichier /home/cyril/claude-code/sites/test.laravel/@DOCS/PROMPTS.md et prend les tâches qui restent à faire" Enter
```

Rendre exécutable :

```bash
chmod +x ~/resume-claude.sh
```

Programmer :

```bash
echo '~/resume-claude.sh' | at now + 162 minutes
```

Cette méthode est beaucoup plus stable.

---

# 18. Alias pratiques

Dans :

```bash
nano ~/.bashrc
```

Ajouter :

```bash
alias reprend='tmux send-keys -t claude "Reprend" Enter'

alias docs='tmux send-keys -t claude "Lis @DOCS/PROMPTS.md et continue les tâches restantes" Enter'

alias status='tmux capture-pane -pt claude'
```

Recharger :

```bash
source ~/.bashrc
```

---

# 19. Lire ce que fait Claude sans ouvrir tmux

```bash
tmux capture-pane -pt claude
```

Très utile pour monitoring.

---

# 20. Boucle automatique

Exemple :

```bash
while true; do
    tmux send-keys -t claude "Continue les tâches restantes" Enter
    sleep 10800
done
```

Relance toutes les 3 heures.

---

# 21. Désactiver la veille Windows

Windows :

```text
Paramètres > Système > Alimentation et mise en veille
```

Mettre :

* Veille : Jamais

Sinon WSL peut s’endormir.

---

# 22. Stack recommandée

## Base

* Windows 10
* WSL Ubuntu
* tmux
* Claude Code
* Git
* VSCode Remote WSL

## IA locale

* Ollama
* GLM
* Qwen
* DeepSeek

## Dev Laravel

* PHP 8.3
* Composer
* Node
* Vite
* MySQL/PostgreSQL

---

# 23. Ce que vous pouvez optimiser

## A. Utiliser plusieurs sessions tmux

Exemple :

```bash
tmux new -s backend
tmux new -s frontend
tmux new -s docs
tmux new -s tests
```

Chaque agent IA a un rôle.

---

## B. Ajouter un watchdog automatique

Exemple :

```bash
while true; do
    if ! tmux has-session -t claude 2>/dev/null; then
        tmux new-session -d -s claude 'claude'
    fi
    sleep 60
done
```

Cela relance automatiquement Claude si crash.

---

## C. Logger toutes les sorties

```bash
tmux pipe-pane -o -t claude 'cat >> ~/claude.log'
```

Permet :

* audit
* historique
* debugging
* mémoire de travail

---

## D. Ajouter des prompts spécialisés

Exemple :

```text
@DOCS/
    PROMPTS.md
    BUGS.md
    ROADMAP.md
    TESTS.md
```

Claude devient beaucoup plus structuré.

---

## E. Utiliser Git automatiquement

Faire commiter Claude régulièrement :

```bash
git add .
git commit -m "checkpoint auto"
```

---

## F. Créer un vrai orchestrateur IA

Vous commencez à approcher une architecture type :

* agent principal
* agents spécialisés
* scheduler
* mémoire projet
* supervision

C’est exactement la direction des systèmes de développement IA modernes.

---

# 24. Niveau supérieur possible

Ensuite vous pourrez ajouter :

* n8n
* Make
* agents Docker
* GitHub Actions
* surveillance logs
* génération tickets
* tests automatiques
* CI/CD autonome

Et là vous passez d’un “assistant IA” à un véritable environnement de développement semi-autonome.

```
```
