# Architecture Multi-Communautés — Entraide

> **Public cible de ce document :** développeurs et décideurs techniques du projet.
> Ce n'est pas un document commercial. Il ne décrit pas une vision, il prend des décisions et les justifie. Chaque section répond à une question concrète : quoi faire, pourquoi, et dans quel ordre.

---

## Table des matières

1. [Décisions architecturales fondamentales](#1-décisions-architecturales-fondamentales)
2. [Modèle de tenant : comment une communauté est identifiée](#2-modèle-de-tenant--comment-une-communauté-est-identifiée)
3. [Tables existantes à modifier](#3-tables-existantes-à-modifier)
4. [Nouvelles tables](#4-nouvelles-tables)
5. [Relations entre entités](#5-relations-entre-entités)
6. [Ce qui doit être fait en premier (chemin critique)](#6-ce-qui-doit-être-fait-en-premier-chemin-critique)
7. [Ce qui peut attendre](#7-ce-qui-peut-attendre)
8. [Points de vigilance et risques techniques](#8-points-de-vigilance-et-risques-techniques)
9. [RGPD et implications multi-tenant](#9-rgpd-et-implications-multi-tenant)

---

## 1. Décisions architecturales fondamentales

Avant d'écrire la moindre migration, quatre décisions structurantes doivent être prises et documentées. Elles ne sont pas réversibles sans refonte majeure.

### Décision 1 — Base de données unique (single-DB multi-tenancy)

**Choix retenu : une seule base de données, toutes communautés confondues.**

Chaque ligne de chaque table "métier" (services, transactions, messages…) porte un `community_id`. L'isolation est assurée par des **Global Scopes Eloquent** : chaque requête est automatiquement filtrée sur la communauté active, détectée à l'entrée de chaque requête HTTP (via sous-domaine ou domaine personnalisé).

**Pourquoi pas une base par communauté ?** Parce que la gestion de N bases de données implique N connexions à maintenir, N séries de migrations à appliquer, et rend impossible toute requête "cross-communauté" (stats globales, recherche inter-communautés, parrainage cross-community). Pour la taille et le stade actuel du projet, la base unique est le bon choix.

**La contrepartie acceptée :** le code applicatif doit être rigoureux. Toute requête oubliant son filtre `community_id` sur une table sensible est une fuite de données. Ce risque est géré par les Global Scopes (voir section 8).

---

### Décision 2 — L'utilisateur est global, son appartenance est locale

Un compte utilisateur est unique sur toute la plateforme. Un utilisateur peut appartenir à plusieurs communautés simultanément, avec un rôle et un statut distincts dans chacune.

En revanche, **le solde de points est local par défaut** : un utilisateur a un solde distinct par communauté. Cela permet à chaque communauté de gérer sa propre économie interne sans interférence. La portabilité des points entre communautés est une fonctionnalité optionnelle et future (voir section 7).

---

### Décision 3 — La visibilité d'un service est portée par le service lui-même

Un service posté dans la communauté de Marseille peut être visible sur le hub global (`entraide.fr`). Ce choix appartient à l'auteur au moment de la publication (case à cocher). La communauté peut restreindre ce droit (communauté fermée = pas de publication globale autorisée).

Ce n'est **pas** une réplication de données : le service reste en base avec son `community_id` d'origine. La visibilité globale est un attribut booléen sur le service lui-même, filtré au moment de l'affichage.

---

### Décision 4 — Le paiement réel est une couche optionnelle au-dessus des points

Les points (monnaie interne) sont le mécanisme central d'échange. Le paiement réel (Stripe, HelloAsso, PayPal) sert uniquement à deux cas : acheter des points, ou régler des cotisations/abonnements à une communauté. Il ne remplace pas les points dans les échanges entre membres.

Chaque communauté peut configurer son propre prestataire de paiement, ou hériter de la configuration globale. La configuration de paiement est stockée de manière chiffrée et jamais exposée côté client.

---

## 2. Modèle de tenant : comment une communauté est identifiée

À chaque requête HTTP, avant toute logique métier, le système doit déterminer dans quelle communauté on se trouve. C'est le **tenant resolver**.

### Comment une communauté est reconnue

Trois mécanismes sont possibles, par ordre de priorité :

**1. Sous-domaine sur entraide.fr** — `marseille.entraide.fr` → on cherche dans `communities` la ligne avec `slug = 'marseille'`.

**2. Domaine personnalisé** — `partage.mon-entreprise.fr` → on cherche dans `communities` la ligne avec `custom_domain = 'partage.mon-entreprise.fr'`.

**3. Hub global** — `entraide.fr` sans sous-domaine → tenant = `null` (hub global, communautés ouvertes visibles).

### Ce que le tenant resolver produit

Une fois la communauté identifiée, son `id` est injecté dans le contexte de la requête. Tous les modèles Eloquent qui ont un trait `BelongsToTenant` appliquent automatiquement le filtre `WHERE community_id = ?` sur chaque `SELECT`, `UPDATE` et `DELETE`.

### Les modèles qui NE sont PAS scopés

Certaines tables sont globales par nature et ne portent pas de `community_id` :

- `users` — un utilisateur est global
- `communities` — évidemment
- `referrals` — le parrainage est cross-community
- `payment_gateways` — configuration infrastructure

---

## 3. Tables existantes à modifier

Cette section liste les tables qui existent aujourd'hui et les champs à ajouter. **Aucun champ existant n'est supprimé ni renommé** — on ne fait qu'ajouter.

---

### Table `users`

La table `users` reste globale (pas de `community_id`). On y ajoute :

| Nouveau champ | Type | Description |
|---|---|---|
| `referral_code` | string (8 car.), unique | Code de parrainage personnel, généré à la création du compte. Exemple : `CYR-4F2A`. Unique sur toute la plateforme. |
| `is_global_admin` | boolean, défaut `false` | Super-administrateur avec accès à l'ensemble de la plateforme et toutes les communautés. |
| `last_community_id` | foreign key nullable | Dernière communauté visitée, pour rediriger l'utilisateur à sa reconnexion. |

**Note importante :** le solde de points ne vit pas dans `users`. Il vit dans `community_memberships` (voir section 4), car un utilisateur a un solde distinct par communauté.

---

### Table `services` (annonces)

C'est la table centrale. Elle doit porter la communauté d'appartenance et les nouvelles capacités de visibilité et de services collectifs.

| Nouveau champ | Type | Description |
|---|---|---|
| `community_id` | foreign key, NOT NULL | Communauté dans laquelle ce service a été publié. |
| `is_globally_visible` | boolean, défaut `false` | L'auteur choisit de rendre ce service visible sur le hub global. Ignoré si la communauté est fermée. |
| `is_collective` | boolean, défaut `false` | Ce service accepte plusieurs participants (cours, atelier, sortie). |
| `max_participants` | integer nullable | Nombre maximum de places si `is_collective = true`. Null = illimité. |
| `scheduled_at` | datetime nullable | Date et heure de l'événement pour les services collectifs. |
| `location_address` | string nullable | Adresse physique pour les événements en présentiel. |
| `meeting_url` | text nullable, chiffré | Lien visio (Zoom, Meet…). Révélé uniquement aux participants confirmés. Ne jamais exposer en clair dans les listes. |
| `requires_manual_approval` | boolean, défaut `false` | L'auteur valide chaque inscription manuellement avant confirmation. |
| `points_per_participant` | integer nullable | Coût en points par participant pour un service collectif. Remplace le champ de coût unitaire si `is_collective = true`. |

**Remarque sur le champ `community_id` :** lors de la migration initiale, les services existants doivent être assignés à la communauté "hub global" (la communauté racine, créée lors du déploiement). Ne pas laisser de `NULL` dans ce champ — il doit être `NOT NULL` en production.

---

### Table `transactions`

| Nouveau champ | Type | Description |
|---|---|---|
| `community_id` | foreign key, NOT NULL | Communauté dans laquelle la transaction a eu lieu. Utilisé pour les statistiques locales et les exports. |
| `type` | enum | `exchange` (échange normal), `escrow_lock` (mise en séquestre), `escrow_release` (libération), `escrow_cancel` (annulation), `referral_reward` (bonus parrainage), `welcome_bonus`, `subscription`. |
| `parent_transaction_id` | foreign key nullable, auto-référence | Pour les services collectifs : les N transactions individuelles des participants sont liées à une transaction "parent" agrégée. |
| `metadata` | JSON nullable | Données contextuelles selon le type : `{"service_participant_id": 12}`, `{"referral_id": 7}`, etc. |

---

### Table `categories`

| Nouveau champ | Type | Description |
|---|---|---|
| `community_id` | foreign key nullable | Si null, la catégorie est globale (visible partout). Si renseigné, la catégorie est locale à cette communauté. |

---

### Table `messages`

| Nouveau champ | Type | Description |
|---|---|---|
| `community_id` | foreign key nullable | Contexte communautaire du message. Permet de filtrer la messagerie par espace quand un utilisateur appartient à plusieurs communautés. Null = message global. |

---

## 4. Nouvelles tables

Ces tables n'existent pas encore et doivent être créées from scratch.

---

### Table `communities`

C'est la table pivot de toute l'architecture. Elle décrit chaque espace communautaire.

| Champ | Type | Description |
|---|---|---|
| `id` | UUID | Identifiant non-devinable, utilisé dans les URLs et le code. |
| `name` | string | Nom affiché. Exemple : "Entraide Marseille". |
| `slug` | string, unique | Identifiant URL. Exemple : `marseille`. Utilisé pour les sous-domaines. |
| `custom_domain` | string, unique, nullable | Domaine personnalisé complet. Exemple : `partage.acme.fr`. |
| `is_active` | boolean | Permet de désactiver une communauté sans la supprimer. |
| `visibility` | enum | `open` (contenu visible par tous, indexé), `closed` (accès restreint aux membres, non indexé). La valeur `closed` est une fonctionnalité payante. |
| `join_mode` | enum | `open` (inscription libre), `approval` (admin valide chaque demande), `invite_only` (lien d'invitation requis), `email_domain` (domaine email vérifié). |
| `allowed_email_domain` | string nullable | Si `join_mode = email_domain`, seules les adresses de ce domaine sont acceptées. Exemple : `acme.fr`. |
| `logo_path` | string nullable | Chemin vers le logo, stocké sur S3 ou équivalent. |
| `primary_color` | string nullable | Couleur hexadécimale pour le thème de l'espace. |
| `currency_name` | string, défaut `"points"` | Nom de la monnaie locale. Exemple : "heures", "graines", "crédits". |
| `welcome_bonus_amount` | integer, défaut `0` | Points crédités automatiquement à chaque nouveau membre de la communauté. |
| `features` | JSON | Interrupteurs pour les modules : `{"referrals": true, "collective_services": true, "payments": false}`. Permet d'activer/désactiver des fonctionnalités par communauté. |
| `payment_config` | JSON chiffré, nullable | Référence à la configuration de paiement active pour cette communauté (voir `payment_configs`). |
| `description` | text nullable | Présentation de la communauté et charte. |
| `parent_community_id` | foreign key nullable, auto-référence | Pour des cas de hiérarchie (ex : réseau de communautés d'une même organisation). Non prioritaire — voir section 7. |
| `plan` | enum | `free`, `association`, `enterprise`. Détermine les limites (membres max, fonctionnalités accessibles). |
| `max_members` | integer nullable | Limite du nombre de membres selon le plan. Null = illimité. |
| `created_by` | foreign key vers `users` | L'administrateur global qui a créé cet espace. |

---

### Table `community_memberships`

Table pivot entre `users` et `communities`. Elle remplace et enrichit une éventuelle table `community_user`. C'est ici que vit le rôle, le statut, et le solde de points d'un utilisateur dans une communauté donnée.

| Champ | Type | Description |
|---|---|---|
| `id` | bigint | Clé primaire standard. |
| `user_id` | foreign key vers `users` | L'utilisateur concerné. |
| `community_id` | foreign key vers `communities` | La communauté concernée. |
| `role` | enum | `member`, `moderator`, `admin`. Un utilisateur peut avoir des rôles différents dans chaque communauté. |
| `status` | enum | `pending` (en attente de validation), `active`, `suspended`, `banned`. |
| `points_balance` | integer, défaut `0` | Solde de points de cet utilisateur dans cette communauté. |
| `joined_at` | datetime | Date d'adhésion effective (statut passé à `active`). |
| `invited_by` | foreign key vers `users`, nullable | Si l'utilisateur a rejoint via un lien d'invitation, référence vers l'invitant. |
| `admin_notes` | text nullable | Notes internes visibles uniquement par les admins et modérateurs de la communauté. Non exposé à l'utilisateur. |

**Contrainte d'unicité :** la paire (`user_id`, `community_id`) est unique — un utilisateur ne peut avoir qu'une ligne par communauté.

---

### Table `referrals`

Gère le système de parrainage : un utilisateur partage son code, quelqu'un s'inscrit via ce code, les deux reçoivent une récompense sous conditions.

| Champ | Type | Description |
|---|---|---|
| `id` | bigint | Clé primaire. |
| `referrer_id` | foreign key vers `users` | Le parrain (celui qui partage son code). |
| `referee_id` | foreign key vers `users`, nullable | Le filleul (celui qui s'est inscrit). Null si le code a été partagé mais pas encore utilisé. |
| `community_id` | foreign key vers `communities`, nullable | Communauté dans laquelle le parrainage a été initié. Si null, parrainage global. |
| `referral_code_used` | string | Copie du code utilisé au moment de l'inscription. Permet l'audit même si le code change. |
| `status` | enum | `pending` (filleul inscrit mais pas encore actif), `validated` (première action réelle accomplie), `rewarded` (récompenses distribuées), `cancelled` (fraude détectée ou compte supprimé). |
| `referee_first_action_at` | datetime nullable | Date à laquelle le filleul a réalisé sa première action qualifiante (premier échange complété, pas juste une inscription). |
| `referrer_reward_amount` | integer nullable | Montant effectivement crédité au parrain. Fixé au moment de la validation, pas au moment de l'inscription (la config peut changer). |
| `referee_reward_amount` | integer nullable | Montant effectivement crédité au filleul. |
| `ip_address_at_signup` | string nullable | IP du filleul à l'inscription, conservée pour détection de fraude (auto-parrainage). À supprimer après X jours pour conformité RGPD. |
| `rewarded_at` | datetime nullable | Date de distribution des récompenses. |

**Logique de validation :** la récompense ne se déclenche pas à l'inscription du filleul mais à sa **première action réelle qualifiante** (par exemple : premier échange de service complété et évalué). Cela évite les inscriptions fictives.

---

### Table `service_participants`

Gère les inscriptions aux services collectifs. Elle n'existe que quand `services.is_collective = true`.

| Champ | Type | Description |
|---|---|---|
| `id` | bigint | Clé primaire. |
| `service_id` | foreign key vers `services` | Le service collectif concerné. |
| `user_id` | foreign key vers `users` | Le participant. |
| `status` | enum | `pending` (en attente de validation manuelle si `requires_manual_approval`), `confirmed`, `waitlisted` (liste d'attente), `cancelled_by_user`, `cancelled_by_host`, `attended` (présence confirmée par l'hôte). |
| `slots_reserved` | integer, défaut `1` | Nombre de places réservées (si l'on vient accompagné). |
| `points_escrowed` | integer | Montant de points mis en séquestre lors de la réservation. Calculé comme `slots_reserved × service.points_per_participant`. |
| `escrow_transaction_id` | foreign key vers `transactions` | Référence à la transaction de type `escrow_lock` créée lors de la réservation. |
| `confirmed_at` | datetime nullable | Date de confirmation par l'hôte (si `requires_manual_approval`). |
| `attended_at` | datetime nullable | Date à laquelle l'hôte a marqué la présence du participant. Déclenche la libération du séquestre. |

**Le mécanisme du séquestre en détail :** quand un participant réserve, ses points sont débités de son solde et créditées à une "transaction séquestre" en attente. Si l'événement a lieu et que l'hôte confirme la présence, le séquestre est libéré vers le solde de l'hôte (`escrow_release`). Si l'événement est annulé ou que le participant se désiste, les points sont recrédités au participant (`escrow_cancel`). Ce mécanisme requiert une **transaction atomique en base de données** (SQL transaction) pour éviter toute incohérence de solde.

---

### Table `payment_configs`

Stocke la configuration des prestataires de paiement, par communauté ou globalement.

| Champ | Type | Description |
|---|---|---|
| `id` | bigint | Clé primaire. |
| `community_id` | foreign key vers `communities`, nullable | Si null, configuration globale par défaut. |
| `provider` | enum | `stripe`, `helloasso`, `paypal`. |
| `is_active` | boolean | Une seule config active par communauté et par provider à la fois. |
| `mode` | enum | `sandbox` (tests) ou `live` (production). |
| `credentials` | text chiffré | Clés API, webhooks secrets, identifiants marchands. **Jamais stocké en clair.** Chiffré avec une clé applicative (ex : Laravel's `encrypt()`). |
| `currency` | string, défaut `EUR` | Devise pour les transactions réelles. |
| `created_by` | foreign key vers `users` | Admin qui a configuré ce prestataire. |

**Note sur HelloAsso :** HelloAsso ne fonctionne pas comme Stripe Connect. Il n'est pas possible d'encaisser directement pour le compte d'une autre entité. Les communautés associatives utilisant HelloAsso doivent avoir leur propre compte HelloAsso et configurer leur propre webhook. C'est une limite à documenter clairement dans l'interface admin.

---

## 5. Relations entre entités

Ce schéma décrit les relations principales, en prose, pour qu'elles soient compréhensibles sans lire du code.

**Un utilisateur** peut appartenir à plusieurs communautés. Chaque appartenance est une ligne dans `community_memberships`, avec son propre rôle, statut et solde de points. C'est une relation many-to-many enrichie.

**Une communauté** contient des membres (via `community_memberships`), des services (via `services.community_id`), et peut avoir plusieurs configurations de paiement (via `payment_configs.community_id`).

**Un service** appartient à une et une seule communauté. S'il est collectif, il peut avoir plusieurs participants via `service_participants`. Chaque inscription génère une transaction de séquestre.

**Une transaction** appartient à une communauté, implique deux utilisateurs (émetteur et récepteur), et peut être liée à un service, une inscription collective, ou un parrainage via le champ `metadata` ou les clés étrangères dédiées.

**Un parrainage** lie deux utilisateurs (parrain et filleul) et peut être rattaché à une communauté spécifique. Il génère deux transactions de récompense (`referral_reward`) quand son statut passe à `rewarded`.

**Une catégorie** est soit globale (pas de `community_id`), soit locale à une communauté. Une communauté hérite des catégories globales et peut y ajouter les siennes.

---

## 6. Ce qui doit être fait en premier (chemin critique)

Ces éléments bloquent tout le reste. Ils doivent être développés dans cet ordre.

### Étape 1 — Créer la table `communities` et la communauté "hub"

Avant tout, créer la table `communities` et y insérer une ligne représentant le hub global (`slug = 'hub'`, `visibility = 'open'`). Cette ligne deviendra la communauté par défaut pour toutes les données existantes.

### Étape 2 — Créer `community_memberships` et migrer les utilisateurs existants

Créer la table `community_memberships`. Ensuite, migrer tous les utilisateurs existants : chaque utilisateur doit avoir une ligne dans `community_memberships` avec `community_id = hub.id`, `role = 'member'`, `status = 'active'`, et un `points_balance` égal au solde actuel de l'utilisateur (qui doit être retiré de `users`).

**Attention :** si le solde est actuellement dans `users.points_balance` ou équivalent, il faut migrer cette valeur et s'assurer qu'après migration, l'ancienne colonne est ignorée (puis supprimée dans une migration ultérieure).

### Étape 3 — Ajouter `community_id` à `services` et `transactions`

Ajouter la colonne `community_id` sur `services` et `transactions`. La remplir avec `hub.id` pour toutes les lignes existantes. Rendre la colonne `NOT NULL`. Ensuite seulement, activer les Global Scopes Eloquent.

### Étape 4 — Implémenter le tenant resolver en middleware

Un middleware Laravel doit s'exécuter en tête de chaque requête pour identifier la communauté active depuis le sous-domaine ou le domaine personnalisé, et l'injecter dans le contexte de l'application. C'est le point d'entrée de toute l'isolation.

### Étape 5 — Créer le système de parrainage

Ajouter `referral_code` dans `users` (générer les codes pour les utilisateurs existants). Créer la table `referrals`. Implémenter la logique de validation et de récompense.

### Étape 6 — Créer les services collectifs

Ajouter les colonnes sur `services`. Créer `service_participants`. Implémenter le séquestre de points (transaction atomique). Implémenter l'interface de gestion des inscriptions pour l'hôte.

### Étape 7 — Créer la configuration de paiement

Créer `payment_configs`. Implémenter l'interface admin locale pour configurer un prestataire. Connecter les webhooks Stripe/HelloAsso.

---

## 7. Ce qui peut attendre

Ces fonctionnalités ont de la valeur mais ne bloquent pas le lancement et introduisent une complexité significative. Elles sont documentées ici pour anticiper leur intégration future sans les construire maintenant.

**Portabilité des points entre communautés.** Permettre à un utilisateur de transférer ou utiliser son solde d'une communauté dans une autre. Cela nécessite une logique de taux de change ou d'équivalence, et des règles de gouvernance (qui autorise un transfert ?). À traiter uniquement après stabilisation du modèle de points local.

**Passerelles inter-communautés (bridges).** Partager un catalogue de services entre deux communautés partenaires, sans fusionner leurs membres. Nécessite une table `community_bridges` et une logique de visibilité plus complexe. Ne pas construire avant d'avoir plusieurs communautés actives en production.

**Hiérarchie de communautés (parent/enfant).** Le champ `parent_community_id` est réservé mais non utilisé. Une fédération de villes sous une région, ou des équipes sous une entreprise, pourrait en bénéficier. La complexité de gouvernance est élevée — à différer.

**Score de réputation global (trust score).** Agréger les évaluations d'un utilisateur sur toutes ses communautés en un score transverse. Utile pour faciliter l'intégration dans une nouvelle communauté. Peut être calculé en dehors de la base (service dédié ou colonne dénormalisée mise à jour asynchroniquement).

**Gouvernance participative et votes.** Permettre aux membres de voter sur les règles de la communauté. Fonctionnalité de niveau produit avancé, pas d'infrastructure.

**Application mobile.** Ne concerne pas le modèle de données — l'API existante suffit. À planifier séparément.

---

## 8. Points de vigilance et risques techniques

### Le risque principal : oublier un Global Scope

L'isolation par `community_id` repose sur des filtres automatiques dans Eloquent. Si un développeur écrit une requête raw SQL, contourne Eloquent, ou oublie d'ajouter le trait `BelongsToTenant` sur un nouveau modèle, les données d'une communauté peuvent fuir vers une autre.

**Mitigation :** revue systématique du code sur toute requête qui touche une table scopée. Tests d'intégration vérifiant l'isolation : un utilisateur de la communauté A ne doit jamais voir les données de la communauté B dans aucune réponse API.

### Le séquestre de points : un problème de concurrence

Si deux utilisateurs réservent la dernière place d'un service collectif simultanément, et que le code ne gère pas correctement la concurrence, les deux réservations peuvent réussir alors qu'il n'y a qu'une place.

**Mitigation :** la vérification du nombre de places disponibles et la création de `service_participants` doivent être dans une transaction SQL avec un verrou optimiste (`LOCK IN SHARE MODE` ou équivalent Laravel). Ne pas faire cette vérification en PHP avant l'insertion — c'est une race condition garantie.

### Le parrainage : risque d'auto-parrainage et de fraude

Un utilisateur peut créer deux comptes avec des adresses email différentes, parrainer le second avec le premier, et encaisser les récompenses.

**Mitigation :** la récompense ne se déclenche qu'après une **première action réelle** (un échange complété, pas juste une inscription). Conserver l'IP à l'inscription pour comparaison (durée limitée pour raisons RGPD). Comparer l'empreinte de navigateur si disponible. Ne pas surprotéger au détriment de l'expérience — quelques abus sont inévitables et peu coûteux au début.

### Les clés de paiement : sécurité absolue

Les credentials Stripe/HelloAsso dans `payment_configs.credentials` ne doivent jamais apparaître dans des logs, des dumps de base de données partagés, ou des réponses API. Utiliser le chiffrement Laravel (`encrypt()`/`decrypt()`) et une clé applicative différente de la clé de session. Restreindre l'accès à cette colonne dans les requêtes (ne jamais la sélectionner dans un `SELECT *`).

### Le routage par sous-domaine : configuration serveur

La détection du sous-domaine est côté applicatif (middleware Laravel), mais le serveur web (Nginx/Apache) doit être configuré pour accepter les wildcards (`*.entraide.fr`) et router vers l'application. Pour les domaines personnalisés, un mécanisme de provisioning SSL automatique (Let's Encrypt via ACME) est nécessaire — ce n'est pas natif à Laravel et doit être planifié au niveau infrastructure avant le lancement des domaines personnalisés.

### La charge sur `community_memberships`

Cette table sera très sollicitée : chaque chargement de page vérifie le rôle et le statut du membre. Indexer impérativement sur (`user_id`, `community_id`) et sur (`community_id`, `status`). Envisager un cache Redis pour les données de membership (rôle, statut, solde) avec invalidation à chaque modification.

---

## 9. RGPD et implications multi-tenant

Dans un modèle multi-tenant, la responsabilité des données personnelles est partagée.

### Qui est responsable de quoi

La plateforme Entraide (Anthropic/l'opérateur global) est **responsable de traitement** pour les données des utilisateurs au niveau du compte global (nom, email, code de parrainage…).

Chaque administrateur de communauté est **responsable conjoint ou sous-traitant** pour les données de ses membres dans son espace. Cette responsabilité doit être formalisée dans les CGU de la plateforme, qui doivent inclure un accord de traitement des données (DPA) pour les communautés traitant des données de salariés (cas entreprise).

### Droit à l'oubli : deux niveaux

**Quitter une communauté :** l'utilisateur quitte la communauté mais conserve son compte global. Sa ligne dans `community_memberships` est supprimée. Ses services dans cette communauté sont anonymisés (auteur remplacé par "Utilisateur anonyme"). Son historique de transactions dans cette communauté est conservé pour l'intégrité comptable de la communauté, mais dépersonnalisé.

**Supprimer son compte global :** suppression de la ligne `users`. Anonymisation en cascade de toutes ses contributions (services, transactions, messages) sur toutes les communautés. Les transactions conservent leur montant et leurs dates (intégrité comptable) mais perdent la référence à l'utilisateur. Cette opération doit être atomique et testée.

### Données à durée de vie limitée

Le champ `ip_address_at_signup` dans `referrals` ne doit être conservé que le temps nécessaire à la vérification anti-fraude (proposition : 30 jours). Une tâche cron doit le vider automatiquement. Le documenter dans le registre des activités de traitement.

### Portabilité des données

Un utilisateur doit pouvoir exporter toutes ses données : profil, historique de transactions, services publiés, messages, sur toutes ses communautés. Cette fonctionnalité d'export doit être accessible en self-service. Elle implique une requête qui traverse toutes les communautés de l'utilisateur — à concevoir avec un job en arrière-plan pour les comptes très actifs.

---

*Document rédigé pour guider les décisions de développement. À mettre à jour à chaque décision architecturale majeure qui s'écarte de ce qui est décrit ici. Version initiale : mai 2026.*
