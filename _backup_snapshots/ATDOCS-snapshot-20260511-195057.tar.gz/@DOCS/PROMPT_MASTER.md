Dans le fichier de tâche, indique toutes les infos nécessaires pour un redémmarage de session, car je vais 
  quitter Claude Code. Ceci à la fin du fichier avec un chapitre "Pour le rédémarrage de session", ainsi tu 
  sauras quoi faire quand je vais te relancer. 