# BouclePro UI Rules

- Maximum 2 CTA par écran
- No glassmorphism
- No gradients except hero
- Border radius: 16px
- Mobile first
- Never use uppercase buttons
- Use whitespace aggressively
- One dominant action per section
- Avoid dark text on colored buttons