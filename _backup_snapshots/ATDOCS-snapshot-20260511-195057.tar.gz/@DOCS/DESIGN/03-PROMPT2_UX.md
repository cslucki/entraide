IMPORTANT — Dependency Management Rules

Because this project is developed across multiple agents and environments, you MUST strictly control dependencies.

From now on:

DO NOT silently install packages.

Before adding ANY dependency, you must provide:

* package name
* exact purpose
* why native Laravel/Livewire/Tailwind solution is insufficient
* frontend or backend impact
* estimated complexity cost
* npm/cargo/composer command required

Example format:

Package:
`@floating-ui/dom`

Purpose:
Tooltip positioning for mobile dropdown consistency.

Why needed:
Native CSS solution insufficient for viewport collision handling.

Install command:
`npm install @floating-ui/dom`

====================================================

VERY IMPORTANT

Prefer:

* native Laravel
* Livewire
* Alpine
* Tailwind
* existing browser APIs

Avoid:

* heavy frontend libraries
* UI kits
* animation frameworks
* unnecessary abstraction layers

====================================================

Before final submission, provide:

1. Full list of installed packages
2. Composer changes
3. NPM changes
4. Build impact
5. Any migration required on local/prod environments
6. Any .env changes
7. Any queue/cache/storage requirements

We must keep deployment predictable and production-safe.
