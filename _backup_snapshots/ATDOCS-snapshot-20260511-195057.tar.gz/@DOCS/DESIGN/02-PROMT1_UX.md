You are now entering a UI/UX refinement phase for BouclePro.

IMPORTANT:
Do NOT redesign randomly anymore.
You must now work from a strict product design system approach.

The current issues are NOT technical.
They are UX consistency and visual hierarchy problems.

====================================================
STACK CONSTRAINT
================

We KEEP the current stack:

* Laravel 13
* Livewire 3
* Alpine.js
* Tailwind CSS v4

Do NOT introduce:

* React
* Vue migration
* Next.js
* external UI frameworks
* heavy animation systems

The objective is to produce a PREMIUM product experience with the EXISTING stack.

====================================================
YOUR NEW PRIORITY
=================

You are no longer only implementing features.

You are acting as:

* senior product designer
* UX engineer
* AI-native interface designer

Every UI decision must optimize:

* clarity
* simplicity
* breathing space
* cognitive ease
* onboarding speed

====================================================
FIRST TASK
==========

Create a DESIGN SYSTEM FOUNDATION for BouclePro.

Before continuing homepage refinements, create:

* UI_RULES.md
* reusable UI component conventions
* spacing rules
* typography hierarchy
* button standards
* form/input standards
* mobile behavior rules

====================================================
CREATE:
=======

/docs/UI_RULES.md

This file should define STRICT rules.

Example topics:

* spacing scale
* border radius
* shadows
* typography sizes
* container widths
* CTA hierarchy
* mobile-first rules
* navbar consistency
* allowed gradients
* allowed colors
* interaction density
* empty state philosophy
* conversational AI input behavior
* dark mode principles

====================================================
VERY IMPORTANT DESIGN RULES
===========================

Add explicit rules such as:

* maximum 2 primary CTAs per section
* avoid visual noise
* avoid glassmorphism overload
* avoid strong gradients except hero
* never use dark text on dark buttons
* mobile screens must feel lighter than desktop
* whitespace is intentional
* AI blocks must feel conversational, not dashboard-like
* no all-caps buttons
* no excessive icons
* one dominant action per viewport

====================================================
CREATE REUSABLE COMPONENT STRATEGY
==================================

Document reusable components:

* HeroSection
* AIInputCard
* IntentHintButtons
* PrimaryButton
* SecondaryButton
* MobileDrawer
* ConversationInput
* SectionTitle
* StatsCard

Goal:
future UI consistency.

====================================================
HOMEPAGE REFACTOR
=================

After creating the design system:

Refactor the homepage according to the previously provided specifications.

Especially:

* keep existing hero
* add AI conversational block below
* simplify mobile heavily
* contextual hint buttons only
* no forced selection
* French UI only
* ChatGPT/Gemini inspiration
* send button INSIDE input
* breathing space
* cleaner typography

====================================================
MOBILE PRIORITY
===============

Mobile experience is CRITICAL.

On mobile:
REMOVE all unnecessary homepage sections.

Focus only on:

* header
* hero text
* conversational input
* optional hint buttons
* hamburger menu
* side menu with “Se connecter” button

Nothing more.

====================================================
PLAYWRIGHT VALIDATION
=====================

You MUST validate:

* desktop
* tablet
* mobile
* dark mode
* menu open states
* responsive spacing

====================================================
REQUIRED DELIVERABLES
=====================

Before final submission provide:

1. Desktop screenshot
2. Desktop with left menu open
3. Mobile screenshot
4. Mobile with menu open
5. Screenshot of dark mode
6. Screenshot of AI block interaction
7. Screenshot showing placeholder changing after hint button selection

IMPORTANT:
Real implementation screenshots only.

====================================================
GOAL
====

The user must immediately understand:

“I can simply describe what I want.”

without needing to understand platform structure first.

The interface should feel:

* calm
* intelligent
* modern
* obvious
* trustworthy
* effortless
