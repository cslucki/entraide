The current implementation is NOT aligned with the expected UX direction.

We are now simplifying and clarifying the homepage experience.

IMPORTANT:
Please carefully follow the new UI/UX specifications below.
The goal is to create a VERY SIMPLE, VERY CLEAR conversational homepage inspired by ChatGPT/Gemini, while preserving the existing BouclePro identity and current hero section.

====================================================
GLOBAL UX DIRECTION
====================================================

We want:

- minimalist
- calm
- premium
- conversational
- intuitive
- fast to understand
- mobile-first
- AI-native feeling

But:

- NOT flashy
- NOT glassmorphism-heavy
- NOT overloaded
- NOT “futuristic SaaS”
- NOT dark gradients everywhere

The current purple gradient/glass style is too aggressive.

Use:
- lots of whitespace
- soft borders
- subtle shadows
- current BouclePro purple only as accent color
- clean typography
- simple interaction patterns

Think:
ChatGPT + Gemini + Linear simplicity.

====================================================
VERY IMPORTANT
====================================================

KEEP the EXISTING current homepage structure and hero section.

DO NOT replace the homepage with a full-screen AI page.

Instead:

ADD the conversational AI input BELOW the existing hero section.

The current hero stays visible.

====================================================
DESKTOP LAYOUT
====================================================

Desktop homepage should contain:

1. Existing navbar
2. Existing hero section
3. Existing CTA buttons
4. THEN the new conversational AI block BELOW

The AI block should include:

- a large centered input area
- rounded borders
- send button INSIDE the textarea/input
- placeholder:
  "Décrivez ce que vous souhaitez faire..."

Below the input:
display action hint buttons.

====================================================
ACTION BUTTONS
====================================================

Buttons must be:

- visually lightweight
- NOT dropdowns
- NOT tabs
- NOT segmented controls
- NOT pills with arrows

They are ONLY contextual hints.

By default:
NO button is selected.

The AI should infer intent from the message itself.

If the user clicks a button:
- it acts as an additional signal
- optional metadata only
- NOT mandatory
- placeholder text changes dynamically

Buttons:

- Proposer un micro-service
- Demander de l’aide
- Publier un article
- Créer un évènement

====================================================
IMPORTANT MOBILE CHANGE
====================================================

On MOBILE:
the interface must be MUCH lighter.

REMOVE:
- counters
- “Créer votre boucle”
- secondary informational sections
- extra statistics
- heavy homepage blocks

Mobile should focus ONLY on:

- logo/header
- hero title
- AI conversational input
- contextual action buttons
- hamburger menu
- login button in side menu

Simple and clean.

====================================================
MOBILE UX
====================================================

Create:

1. Mobile without menu open
2. Mobile with left menu open

Menu style should follow ChatGPT mobile navigation.

Bottom of menu:
purple “Se connecter” button.

====================================================
INPUT BEHAVIOR
====================================================

The send button must be INSIDE the input zone.

Large conversational field:
similar to ChatGPT/Gemini proportions.

Desktop:
wider and breathing.

Mobile:
compact but still conversational.

====================================================
BUTTON BEHAVIOR
====================================================

Current implementation with radio behavior is WRONG.

New behavior:

- no default selected state
- user can optionally click one
- AI still works without any selected option

Technically:
treat them as optional intent hints.

If one is selected:
update placeholder dynamically.

Example:

Selected:
“Publier un article”

Placeholder becomes:
“Quel sujet souhaitez-vous publier ?”

====================================================
LANGUAGE
====================================================

ALL visible UI must be in French.

No English text anywhere.

====================================================
DESIGN REFERENCES
====================================================

Use as inspiration:
- ChatGPT homepage
- Gemini homepage
- Linear
- Notion

But KEEP BouclePro branding.

====================================================
DELIVERABLES REQUIRED
====================================================

Before final validation, provide:

1. Desktop screenshot
2. Desktop screenshot with left menu open
3. Mobile screenshot
4. Mobile screenshot with left menu open

IMPORTANT:
I want REAL screenshots from the implementation.
Not descriptions.

Also provide:
- Playwright validation
- responsive verification
- dark mode verification

====================================================
TECHNICAL NOTES
====================================================

Do NOT overengineer.

No:
- animations overload
- AI chat history
- streaming
- fake chatbot
- assistant avatars

This is simply:
an intelligent conversational entry point for the platform.

====================================================
FINAL GOAL
====================================================

The user should immediately understand:

“I can simply describe what I want.”

without friction,
without complex onboarding,
without needing to understand the platform structure first.