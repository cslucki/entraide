for branch in \
glm/TASK-EMAIL-001 \
jules/TASK-018-14773830141485825826 \
opencode/OpenCodeTask-004-smart-auth-redirect \
opencode/OpenCodeTask-005-community-landing
do
  echo ""
  echo "======================================"
  echo "BRANCH: $branch"
  echo "======================================"
  git log --oneline develop..$branch
done > @DOCS/@temp/24-inspecter_commit_uniques.txt