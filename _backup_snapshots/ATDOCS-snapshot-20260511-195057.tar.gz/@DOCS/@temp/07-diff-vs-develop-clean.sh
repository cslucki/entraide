for branch in \
claude/TASK-016 \
claude/TASK-030-community-multitenancy \
gemini/toggle_color_mode \
gemini/toggle_color_mode_tests \
main
do
  echo ""
  echo "======================================"
  echo "BRANCH: $branch"
  echo "======================================"
  git diff --stat develop-clean..$branch
done > 07-diff-vs-develop-clean.txt