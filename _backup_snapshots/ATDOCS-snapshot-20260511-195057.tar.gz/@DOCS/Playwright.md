Les tests dans /home/cyril/claude-code/sites/test.laravel/tests utilisent @playwright/test (standard Playwright), pas le MCP Playwright. Ce sont deux choses différentes :
- tests/e2e/smoke.spec.js → Playwright Test (framework de test)
- MCP Playwright → Outils d'automatisation via protocole MCP pour IA
# Commandes principales MCP Playwright
Une fois OpenCode redémarré, vous aurez ces outils MCP :
## Navigation et base
- browser_navigate → Ouvre une URL
- browser_go_back / browser_go_forward → Navigation
- browser_reload → Recharge la page
## Snapshots et état
- browser_snapshot → Récupère l'arbre d'accessibilité (pour voir les éléments)
- browser_network_requests → Voir les requêtes réseau
## Interactions
- browser_click → Clique sur un élément (via ref du snapshot)
- browser_type → Tape du texte dans un champ
- browser_fill → Remplit un formulaire
- browser_select_option → Sélectionne dans un menu déroulant
- browser_check / browser_uncheck → Cases à cocher
- browser_hover → Survole un élément
- browser_drag → Glisser-déposer
## Captures
- browser_screenshot → Capture d'écran
- browser_pdf_save → Sauvegarde en PDF
## Onglets
- browser_tab_list → Liste les onglets
- browser_tab_new → Nouvel onglet
- browser_tab_select → Change d'onglet
- browser_tab_close → Ferme un onglet
## Avancé
- browser_evaluate → Exécute du JS dans la page
- browser_close → Ferme le navigateur
- browser_resize → Redimensionne la fenêtre

# Comment utiliser le MCP

Dans OpenCode, demandez simplement en langage naturel :
Navigue vers https://test.laravel/ et fais une capture d'écran

L'IA utilisera automatiquement les outils MCP. Exemple de flux :
1. AI appelle browser_navigate avec url: "https://test.laravel/"
2. AI appelle browser_snapshot pour voir la page
3. AI appelle browser_screenshot pour capturer

## Scripts avec MCP
Le MCP Playwright ne s'utilise pas avec des scripts .spec.js classiques. Il s'utilise via l'IA. Cependant, vous pouvez créer des scripts en demandant à l'IA de faire une série d'actions :

Exemple de demande à l'IA :

Fais un script de test qui :
1. Va sur https://test.laravel/
2. Clique sur "Connexion"
3. Remplit email: test@example.com, password: password
4. Valide et capture le dashboard

L'IA générera les appels MCP appropriés.

## Compatibilité des tests existants
Fichier	Compatible MCP ?
    tests/e2e/smoke.spec.js	❌ Non
    tests/Feature/	❌ Non
    tests/Unit/	❌ Non
Pour convertir smoke.spec.js en utilisation MCP, il faudrait refaire les tests en demandes naturelles à l'IA.