# Create task
./ai/scripts/create-task.sh "Enforce agent task discipline"
-> TODO/TASK-053-enforce-agent-task-discipline.md

# Serveur playwright
npx playwright show-report ai/playwright/reports/html
http://localhost:9323/
Ensuite voir ai/playwright/test-results
## Si tourne déjà
lsof -i :9323
