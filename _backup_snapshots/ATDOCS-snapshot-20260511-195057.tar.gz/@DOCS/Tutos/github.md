# Casser la branche
git checkout main
git reset --hard # 1. Annuler toutes les modifications locales
git clean -fd # 2. Supprimer aussi les fichiers non suivis
git status # 3. Vérifier que tout est propre
git checkout main # 4. Revenir sur main
git branch -D feat/ai-homepage-orchestration-2146373821344109155 # 5. Supprimer la branche locale
git push origin --delete feat/ai-homepage-orchestration-2146373821344109155 # 6. Supprimer la branche distante

# Créer une branche 
git checkout main
git pull origin main
git checkout -b TASK-056-build-community-transaction-qa-matrix

# Récupérer fichiers effacés
git status
git restore docs/

# Commande pour commiter
~/.bashrc
alias snap='git add . && git commit -m "snapshot: $(date "+%Y-%m-%d %H:%M:%S")"'
source ~/.bashrc
snap #Avant toute opération risquée, on fait un snapshot

# En fin de boulot sur une branche
git status
git diff --stat
git diff
## Puis on lance le script /home/cyril/claude-code/sites/test.laravel/_bash_cyril/01_before_commit.sh
git add composer.json composer.lock TODO/TASK-055-build-agentic-playwright-qa-architecture.md
git commit -m "chore: remove experimental laravel MCP server package"
# le transfert se fait à ce moment
git push origin TASK-055-build-agentic-playwright-qa-architecture 
# on retourne sur develop
git checkout develop
# on merge la task 
git merge TASK-055-build-agentic-playwright-qa-architecture

Une fois le merge fait :

git checkout develop
npm install
composer install
php artisan test
npx playwright test

===
git checkout develop
git pull origin develop
git checkout main
git pull origin main
git merge develop
git push origin main
===

# Récupérer une PR
## Lister les PR sur GitHUB
gh pr list
## voir les différences
git diff develop --name-only

composer install
npm install
npm run build
php artisan migrate


# WORKFLOW SIMPLE
## 1. Sauvegarder temporairement
git stash push -m "notes workflow temporaire"
## 2. Changer de branche
git checkout main
ou : git checkout jules/...
## 3. Revenir plus tard
git checkout develop
## 4. Restaurer
git stash pop

# Divers
## Lister proprement les fichiers modifiés
git status --short
## restaurer les suppressions
git restore ai/scripts/01concatener_ai_files.sh \
ai/scripts/02send-resume_tmux.sh
## vérifier état propre
git status
## ajouter les bons fichiers
git add TODO/TASK-054-setup-playwright-review-workflow.md \
ai/scripts/capture-page.js \
ai/workflows/playwright-review.md
## ajouter tous les changements
git add
## commit
git commit -m "feat: add Playwright review workflow"
##  pousser la branche TASK-054
git push origin TASK-054-setup-playwright-review-workflow
## revenir sur develop
git checkout develop
## merger TASK-054 → develop
git merge TASK-054-setup-playwright-review-workflow
## push develop = Pousser la branche develop vers GitHub
git push origin develop




## Commit libre humain sur Branche ou un agent travail
SKIP_TASK_CHECK=1 git commit -m "notes personnelles"

## avoir toutes les branches
git branch -vv | tee @DOCS/branches_vv.txt
git fetch --all && git branch -vv > @DOCS/git_branch_vv.txt && git branch -a > @DOCS/git_branch_all.txt

## Nettoyer branches
git checkout develop
git merge glm/TASK-EMAIL-001
git status
php artisan test

## Commit en 1 fois
git checkout develop
git checkout -b ai/recovery
git checkout gemini/toggle_color_mode -- ai/
tree ai
git status
git add ai
git commit -m "Restore modular AI system directory"
 git push -u origin develop-clean

## sauvegarde psychologique
git tag backup-before-cleanup
git push origin backup-before-cleanup

# Branche main
Très bonne question 👍
Et là vous touchez à un point fondamental :

**tester plusieurs branches localement sans casser votre environnement.**

Avec Laravel + Apache + Git, il y a plusieurs méthodes.
La plus propre pour vous actuellement :
## 1️⃣ Changer de branche
Exemple :

```bash id="r4m8q2"
git checkout develop
```

ou :

```bash id="u7m2q5"
git checkout main
```

---

## 🥇 2️⃣ Recompiler l’environnement frontend

Très important avec :

* Vite
* Tailwind
* Alpine
* dark mode
* assets compilés

Après changement de branche :

```bash id="n5m8q1"
npm install
npm run dev
```

ou :

```bash id="x4m8q2"
npm run build
```

---

## 🥇 3️⃣ Nettoyer les caches Laravel

Très important.

```bash id="p5m8q1"
php artisan optimize:clear
```

---

## 🥇 4️⃣ Vérifier migrations éventuelles

Si la branche change la DB :

```bash id="k8m1q4"
php artisan migrate
```

---

## 🥇 5️⃣ Tester dans Apache

Ensuite :

* recharge page
* Ctrl+F5
* tester UI

---

## 🧠 IMPORTANT

Le vrai piège :

## les assets compilés.

Vous pouvez :

* changer de branche
* MAIS garder anciens assets
* et croire que le code ne change pas

😄

Donc :

```bash id="v2m7q4"
npm run dev
```

est souvent indispensable.

---

## 🥇 Workflow ultra pratique pour vous

## Branche develop

```bash id="m8q1p4"
git checkout develop
php artisan optimize:clear
npm run dev
```

Tester.

---

## Branche main

```bash id="j7m2q4"
git checkout main
php artisan optimize:clear
npm run dev
```

Tester.

---

## 🚀 Encore mieux plus tard

Quand vous serez plus avancé :
vous pourrez avoir :

```text id="g4m8q1"
/sites/test.laravel-main
/sites/test.laravel-develop
```

👉 deux working copies séparées.

Comme ça :

* zéro checkout
* zéro recompilation
* comparaison instantanée

💥 énorme confort pro.


