````md
# Agentic Workflow — Mandatory Task Discipline

## Objective

This workflow enforces disciplined multi-agent collaboration using:

- Git branches
- Task files
- Pre-commit validation
- Shared AI workflows
- Human override when necessary

The goal is to prevent:
- undocumented commits
- lost context
- invisible agent modifications
- broken handoffs
- chaotic multi-agent behavior

---

# Architecture

## Main Branches

| Branch | Purpose |
|---|---|
| main | Stable production branch |
| develop | Integration branch |
| TASK-* | Feature/task branches |

---

# Task Lifecycle

Every important modification must be linked to a task file.

Example:

```text
TODO/TASK-053-enforce-agent-task-discipline.md
````

Task files are the operational source of truth.

They contain:

* objective
* progress log
* tests
* handoffs
* review notes
* ownership

---

# Mandatory Rule

## Before ANY commit

Agents MUST:

* update the task file
* stage the task file
* commit with the task file included

If no task file is staged:

* commit is blocked automatically

---

# Scripts

## validate-task-update.sh

Location:

```text
ai/scripts/validate-task-update.sh
```

Purpose:

* checks staged files
* verifies at least one TASK file is included
* blocks invalid commits

---

## install-hooks.sh

Location:

```text
ai/scripts/install-hooks.sh
```

Purpose:

* installs git pre-commit hooks automatically

---

# Installing Hooks

Run once per machine:

```bash
./ai/scripts/install-hooks.sh
```

This creates:

```text
.git/hooks/pre-commit
```

---

# Normal Workflow

## 1. Create task

```bash
./ai/scripts/create-task.sh
```

---

## 2. Work on develop or TASK branch

Example:

```bash
git checkout develop
```

or:

```bash
git checkout TASK-053-enforce-agent-task-discipline
```

---

## 3. Update task file

Example:

```md
## Progress Log

Implemented:
- validate-task-update.sh
- install-hooks.sh
```

---

## 4. Stage files

```bash
git add .
```

---

## 5. Commit

```bash
git commit -m "feat: enforce agent task discipline"
```

If no TASK file is staged:
commit is refused.

---

# Human Override (Bypass)

Some commits are not task-oriented:

* personal notes
* docs
* experiments
* temporary files

For these cases:

```bash
SKIP_TASK_CHECK=1 git commit -m "docs: add tutorial"
```

This bypass must remain exceptional.

---

# Testing The Workflow

## Expected Behavior

### Commit WITHOUT task file

```bash
git commit -m "test"
```

Result:

```text
ERROR:
No TASK file staged.
```

---

### Commit WITH task file

Commit succeeds.

---

### Commit WITH bypass

```bash
SKIP_TASK_CHECK=1 git commit -m "docs update"
```

Commit succeeds.

---

# Git Stash Workflow

Useful for temporary local work.

## Save temporary changes

```bash
git stash push -m "temporary notes"
```

---

## Restore later

```bash
git stash pop
```

---

# Recommended Multi-Agent Rules

## Agents MUST

* update task files continuously
* document handoffs
* document tests
* avoid undocumented commits
* avoid direct work on main

---

## Humans SHOULD

* use bypass consciously
* keep commits clean
* separate workflow changes from product changes

---

# Production Workflow

## develop → main

When validated:

```bash
git checkout main
git merge develop
git push origin main
```

Laravel Cloud deploys automatically from main.

---

# Future Improvements

Possible future validations:

* updated_at freshness
* owner validation
* branch/task consistency
* mandatory test sections
* automatic handoff validation

---

# Philosophy

The task file is not documentation.

It is:

* operational memory
* distributed coordination
* agentic governance
* workflow accountability

The system should enforce discipline automatically,
not rely on memory alone.

```
```
