# A FAIRE
------------------------------------------------------------------------------------

1. Sur https://test.laravel/profile/edit, traduire : 
"Profile Information
Update your account's profile information and email address."
Et "Save"
2. Change le terme "Demande" par "Demande d'aide". 
Ceci notamment dans
- https://test.laravel/explorer
- https://test.laravel/dashboard (je crois l'avoir fait, mais vérifie)
- Dans le menu du header 
- Dans la page d'accueil "Voir les demandes d'aide"
- https://test.laravel/requests/create "Faire une demande d'aide" au lieu de "Proposer une demande" et ajouter Description de votre demande d'aide ou lieu de "Description". Je dis "Faire une demande d'aide", car cela doit rester homogène avec le bouton "Publier" dans le header.
Concernant le warning de "Faire une demande d'aide", il faudra donc en faire un et l'adapter au contexte.

Du coup, mets ces termes dans le fichier dédié aux textes, pour que ce soit plus facile à modifier à l'avenir.
3. Quand on saisi un micro-service ou une demande d'aide, si on n'a pas rempli les informations de son profil, on doit être invité à remplir sa présentation et sa localisation avant de pouvoir publier. C'est ok. Sauf que quand on rempli ses informations de profil, il faut qu'on puisse revenir sur la saisie. 
4. Sur https://test.laravel/services/create que ce soit une demande d'aide ou un micro-service, il faut mettre le warning, qui est actuellement : 
                <p class="font-semibold mb-1">Un {{ $T['service'] }}, c'est une compétence que vous proposez en échange de points.</p>
                <p class="opacity-80">Décrivez précisément ce que vous faites, comment, et ce que le membre obtiendra. Ce n'est pas une annonce de recherche d'emploi — si vous cherchez une mission, utilisez plutôt "Faire une demande".</p>
Sauf qu'on va dire "Faites une demande d'aide" et choisissez la catégorie "Trouver du travail" pour ce type de besoin.
Pour la page 

5. Sur la page "Propositions" (https://test.laravel/explorer), on voit les catégories, mais pas les compétences, il faudrait trouver un moyen de les afficher quand on clique sur une catégorie, ou alors les afficher directement sous la catégorie mais ça fera trop, car sur le site de prod, il y a 10 catégories et 5 compétences par catégorie, ça ferait 50 compétences affichées, ce qui n'est pas très esthétique. Donc il faudrait trouver un moyen de les afficher au clic sur la catégorie, ou alors faire un système de tooltip au hover sur la catégorie pour afficher les compétences associées. A toi de voir ce qui est le plus simple à mettre en place et le plus esthétique.

6. Barême de points et infos sur comment se présenter 
(car tout le monde que cela marche comme Fiiver ou Malt, et du coup les gens mettent des annonces de recherche d'emploi dans les propositions de micro-services, alors que ce n'est pas du tout le but du site).
Dans les 2 formulaires de "propositions", faut ajouter une note concernant les points.
Avant ca y était : 
"Fourchettes recommandées :
Essentiel : 40–60 pts (20 à 30 min)
Standard : 60–80 pts (30 à 45 min)
Complet : 80–100 pts (45 à 60 min)"
Sinon les membres ne seront pas quoi mettre.
Dire que aussi le minimum et maximum de points qu'on peut attribuer.
En rappelant peut-être que tout cela est indicatif, et que chacun est libre de proposer ce qu'il veut, mais que c'est pour aider à se repérer.
Que nous sommes sur une plateforme de troc, donc que les points ne sont pas de l'argent, mais qu'ils permettent d'évaluer la valeur d'un micro-service ou d'une demande d'aide, et ainsi de faciliter les échanges entre les membres.
Ou sinon de rappeler que chacun peut présenter ses services et les liens vers leur site et profil LinkedIN dans l'annuaire (à partir de la présentation) et mettre un lien pour ceux qui veulent modifier. 

7. Dans le menu du site (et aussi sur mobile), il faut modifier "Paramètres" et dire "Profil et paramètres".
8. Toujours sur la même page, il faut que l'utilisateur puisse choisir si on peut voir son email et son téléphone. Par défaut c'est activé à NON, mais il peut choisir de l'afficher. Et dans ce cas, ceci apparait dans l'annuaire. Idem sur le téléphone, j'en parle plus juste après.
9. Important et j'ai oublié, il faut rajouter le téléphone du membre. Du coup, quand un membre se connecte, ce champs est obligatoire et il devra le remplir. C'est aussi une obligation si on veut publier une proposition (micro-service ou demande d'aide). Par défaut, ce champ n'est pas affiché dans le profil public, mais l'utilisateur peut choisir de l'afficher ou pas. Et si il choisit de l'afficher, il apparait dans l'annuaire et sur son profil public. Idem pour l'email. 
10. On va remplacer "Propositions" par "Échanges", car c'est plus cohérent avec "Echanges réalisés". Donc en fait on affiche les échanges en cours, non réalisés. 
6. Sur la page d'accueil, tu dis "Au sein de votre réseau professionnel — votre boucle", pas clair, il faudrait dire "Créez votre réseau professionnel local — votre boucle". Car le terme "local" est important, c'est ce qui différencie notre plateforme des autres plateformes de troc de services, c'est que nous sommes basés sur la proximité géographique, et que nous encourageons les échanges locaux pour favoriser les liens sociaux et la solidarité de proximité.

7. Dans /services/create, la couleur du texte pour les compétences est noir dans le mode dark. Donc on ne voit rien !!!