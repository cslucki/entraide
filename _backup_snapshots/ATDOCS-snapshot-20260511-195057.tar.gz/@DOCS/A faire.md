## CRM
À travers le dashboard du super admin :
### historique contacts
- pour chaque utilisateur on peut saisir des informations via u formulaire
- Dans ce formulaire, il y a une nouvelle catégorie et par défaut la catégorie est "Contact". 
- On peut ajouter dmm8
- es catégories. 
- Ces informations sont poussées dans un historique. 
-  on peut consulter les informations par date ou par catégorie. 
Avoir un historique des contacts avec un utilisateur donné.



### communication email

- Avoir l'ensemble des e-mails qu'on envoi 
- Pouvoir créer des nouveaux mails types. 
- Avoir l'historique des emails envoyés sur un utilisateur donné 

