# z.ai
27911c4a024e443ca455e805e9bef521.4ypGgIOX5Ag5nq2u
# stitch 
AQ.Ab8RN6Ly2oPwKe2ntRBap4f07brT9sU3wuHojhDMWNRXWWUX2A
claude mcp add stitch --transport http https://stitch.googleapis.com/mcp --header "X-Goog-Api-Key: AQ.Ab8RN6Ly2oPwKe2ntRBap4f07brT9sU3wuHojhDMWNRXWWUX2A" -s user
# Open AI
OPENAI_API_KEY=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
# laravel cloud
DB_NAME = main
DB_CONNECTION=pgsql
DB_HOST=ep-weathered-brook-a5rwsu6o.aws-us-east-2.pg.laravel.cloud
DB_PORT=5432
DB_USERNAME=laravel
DB_PASSWORD=npg_PZXC2hxyFS7u


## Commande
pg_dump \
  -h ep-weathered-brook-a5rwsu6o.aws-us-east-2.pg.laravel.cloud \
  -p 5432 \
  -U laravel \
  -d main \
  > production.sql

PGPASSWORD='npg_PZXC2hxyFS7u' pg_dump \
  "sslmode=require host=ep-weathered-brook-a5rwsu6o.aws-us-east-2.pg.laravel.cloud port=5432 dbname=main user=laravel" \
  > production.sql