# IMPORTANT — Non-conformités TASK-EMAIL-001

> Audit réalisé le 2026-05-06 sur la branche `glm/TASK-EMAIL-001`.
> Ces problèmes doivent être corrigés avant merge vers `main`.

---

## 🔴 Bloquant (crashes / 404 garantis)

### 1. `use` imports manquants dans `routes/web.php`

Les deux controllers sont déclarés dans les routes sans être importés.
Laravel lève une `ReflectionException` au boot → **toute l'application crash**.

**À ajouter** en tête de `routes/web.php` :
```php
use App\Http\Controllers\Admin\AdminEmailTemplatesController;
use App\Http\Controllers\Admin\AdminEmailLogsController;
```

---

### 2. Vues Blade manquantes

Aucun dossier `resources/views/admin/email-templates/` ni `resources/views/admin/email-logs/` n'existe.
Toutes les routes email retournent une `InvalidArgumentException` (vue introuvable).

**Vues à créer :**
- `admin/email-templates/index.blade.php`
- `admin/email-templates/create.blade.php`
- `admin/email-templates/edit.blade.php`
- `admin/email-templates/show.blade.php`
- `admin/email-logs/index.blade.php`
- `admin/email-logs/show.blade.php`

---

### 3. Migrations non jouées

`email_templates` et `email_logs` sont en statut **Pending** — les tables n'existent pas en base.

```bash
php artisan migrate
```

---

## 🟠 Non-conformités architecturales (CLAUDE.md)

### 4. Index redondant dans la migration `email_templates`

`slug` a `unique()` (crée déjà un index unique) **et** `$table->index('slug')` → index dupliqué inutile.

**Fichier :** `database/migrations/2026_05_06_200422_create_email_templates_table.php`

**À supprimer :**
```php
$table->index('slug'); // ← redondant avec unique()
```

---

### 5. 3 requêtes COUNT séparées dans `AdminEmailLogsController`

```php
// Actuellement — 3 requêtes SQL
$stats = [
    'total' => EmailLog::count(),
    'sent'  => EmailLog::where('status', 'sent')->count(),
    'failed'=> EmailLog::where('status', 'failed')->count(),
];
```

**À remplacer** par une seule requête groupée :
```php
$counts = EmailLog::selectRaw("count(*) as total, sum(status='sent') as sent, sum(status='failed') as failed")
    ->first();
$stats = ['total' => $counts->total, 'sent' => $counts->sent, 'failed' => $counts->failed];
```

---

### 6. Pas de tests Feature

Aucun test pour les nouveaux controllers. Le cycle VALIDATE de CLAUDE.md exige des tests.

**À créer :**
- `tests/Feature/Admin/AdminEmailTemplatesTest.php`
- `tests/Feature/Admin/AdminEmailLogsTest.php`

---

## 🟡 Mineur

### 7. `preview()` retourne du HTML brut

`AdminEmailTemplatesController::preview()` retourne directement `$validated['content']` sans encapsulation.
Risque XSS limité (admin uniquement), mais mauvaise pratique.

**Fichier :** `app/Http/Controllers/Admin/AdminEmailTemplatesController.php:82`

---

## Fichiers concernés

| Fichier | Problème |
|---|---|
| `routes/web.php` | imports `use` manquants (#1) |
| `resources/views/admin/email-templates/` | dossier + vues à créer (#2) |
| `resources/views/admin/email-logs/` | dossier + vues à créer (#2) |
| `database/migrations/2026_05_06_200422_create_email_templates_table.php` | index redondant (#4) |
| `app/Http/Controllers/Admin/AdminEmailLogsController.php` | 3 COUNT séparées (#5) |
| `tests/Feature/Admin/AdminEmailTemplatesTest.php` | à créer (#6) |
| `tests/Feature/Admin/AdminEmailLogsTest.php` | à créer (#6) |
| `app/Http/Controllers/Admin/AdminEmailTemplatesController.php` | preview XSS (#7) |
