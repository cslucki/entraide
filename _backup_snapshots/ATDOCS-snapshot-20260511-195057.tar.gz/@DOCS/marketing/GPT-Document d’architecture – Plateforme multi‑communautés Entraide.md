# Document d’architecture – Plateforme multi‑communautés Entraide

Entraide évolue vers une **architecture multi‑communautés**, à l’image d’un WordPress Multisite. Il s’agit de disposer d’une plateforme globale (entraide.fr) et d’espaces locaux (villes, associations, entreprises) reliés mais partiellement indépendants. Par exemple, la ville de Marseille a lancé sa propre plateforme « Entraidons‑nous » pour permettre aux habitants et aux associations de publier des offres ou demandes d’aide géolocalisées【58†L1436-L1443】. L’ambition est que chaque communauté ait son sous‑domaine (ex. marseille.entraide.fr) et que les utilisateurs puissent proposer un service dans leur communauté locale **et/ou** sur la plateforme globale. La configuration “ouverte/fermée” de chaque communauté (données visibles de tous ou seulement des membres, avec option payante) sera gérée par l’administrateur. Les administrateurs sont hiérarchisés : un super-admin global, des admins locaux de communauté, puis les utilisateurs normaux. 

Cette plateforme devra donc stocker des informations sur les **utilisateurs**, les **communautés**, les **services annoncés**, ainsi que sur les **relations** entre eux (inscription dans une communauté, participation à un service, parrainage, paiements, etc.). Ci-dessous, nous décrivons les nouveaux éléments de données, les modifications requises, les relations, ainsi que les décisions d’architecture à prendre en priorité. Nous illustrons aussi des modèles éprouvés (WordPress Multisite, Salesforce) et citons des exemples inspirants (Communo, Mobilizon). Enfin, nous listons concurrents et risques techniques.

## Nouvelles entités (tables) et leurs champs principaux 

- **Communautés** – Chaque « communauté » (ville, association, entreprise) est une entité. Il faut une table `communities` avec au minimum :  
  - `id` (identifiant unique)  
  - `name` (nom de la communauté) et éventuellement `description`  
  - `subdomain` ou `slug` (nom de sous‑domaine optionnel)  
  - `is_open` (booléen : communauté ouverte ou fermée)  
  - `admin_user_id` (ID de l’admin principal, ou plusieurs liens via table de liaison)  
  - `payment_config_id` (lien vers configuration de paiement locale, voir plus bas)  
  - Autres champs possibles : logo, localisation, règles particulières, etc.  

- **Membres de communauté** – Si certaines communautés sont fermées (payantes), il faut enregistrer les utilisateurs membres. Table pivot `community_users` :  
  - `community_id`, `user_id` (associations)  
  - `role` ou `status` (ex. « membre », « invité », rôle spécial dans la communauté)  
  - `joined_at` (date d’inscription)  
  Cela permet de savoir qui appartient à quelle communauté et d’appliquer des permissions (par exemple seuls les membres peuvent voir les annonces d’une communauté fermée).

- **Parrainage** – Chaque utilisateur se voit attribuer un **code parrain unique** à son inscription. On peut ajouter dans la table `users` un champ `referral_code` (chaîne unique) et un champ `referred_by` (ID de l’utilisateur sponsor, peut-être `null` si aucun). Alternativement, une table `referrals` :  
  - `referrer_id` (parrain), `referred_id` (filleul), `used_code` (le code utilisé), `created_at`  
  Permet de garder l’historique et de créditer récompenses.  

- **Services (annonces)** – La table `services` (ou `posts`) existante devra intégrer le modèle multi‑communautés :  
  - `id`, `user_id` (auteur), `title`, `description`, etc. (base existante).  
  - **Nouvelles colonnes** :  
    - `max_participants` (nombre max de participants, 1 par défaut pour un service individuel)  
    - `meeting_link` (URL de visioconférence)  
    - `physical_address` (adresse physique, texte)  
    - `is_global` (booléen ou `is_global` indiquant si l’annonce apparaît sur le site global)  
    - **Pour la communauté** : on peut ajouter `community_id` (lien vers la communauté d’origine de l’annonce).  
      - *Option 1* (simple) : `services.community_id`, la communauté locale de l’annonce.  
      - *Option 2* (plus flexible) : une table pivot `service_communities` liant un service à une ou plusieurs communautés (si on veut autoriser un service local partagé sur plusieurs communautés simultanément). Par exemple, un service *cours collectif* du foyer de Marseille qui apparaît à la fois sous Marseille et sous « entraide.fr ».  
    - Ces champs permettent de gérer les **services collectifs** (groupe) avec plusieurs participants et leur lieu.  

- **Participants aux services** – Pour les cours collectifs ou événements, créer une table `service_participants` :  
  - `id`, `service_id`, `user_id` (participant), `status` (inscrit, confirmé, etc.), `joined_at`.  
  - Utile si on limite le nombre de participants ou gère une liste d’attente.  

- **Paiement / Contribuables** – Chaque communauté ou la plateforme globale peut intégrer des paiements. Créer une table `payment_configs` :  
  - `id`, `community_id` (NULL pour global, ou l’ID de communauté),  
  - `provider` (enum: HelloAsso, Stripe, PayPal, etc.),  
  - `config_data` (JSON ou champs spécifiques : clefs API, compte, etc.),  
  - `is_active`.  
  Cette table permet de configurer, pour chaque communauté, quels moyens de paiement utiliser. Les transactions (table `payments` ou logs) pourraient être ajoutées plus tard si besoin.  

En résumé, les **nouvelles tables** essentielles sont : `communities`, `community_users` (membres), `referrals` (parrainage) ou champs associés, `service_participants`, et `payment_configs`. Ces entités forment le cœur du modèle multi‑communautés. 

## Modifications des tables existantes

Plusieurs tables actuelles devront être **étendues** :  

- **Users** : ajouter les colonnes `referral_code` (texte unique) et `referred_by` (ID d’utilisateur). Éventuellement un champ `global_role` (ex : super-admin, normal). Lier aussi un utilisateur à sa communauté d’origine (ex. `home_community_id`) si nécessaire, pour savoir d’où il vient.  
- **Services/annonces** : ajouter les champs évoqués ci-dessus (`max_participants`, `meeting_link`, `physical_address`, `is_global`). Le lien `community_id` peut être dans cette table. Si on opte pour un pivot `service_communities`, on n’ajoute plus `community_id` ici mais on crée la table associée.  
- **Autres entités existantes** : selon le schéma actuel (non fourni ici), tout contenu devant être lié à une communauté (ex. catégories de services, forums, fichiers, etc.) devrait recevoir un champ `community_id` ou utiliser un pivot pour être multicommunautaire. Il faut identifier toutes les tables dont les données sont *affichées* ou *filtrées* par communauté, et prévoir de les marquer.  

- **Roles/permissions** : on pourrait avoir une table de rôles ou de permissions utilisateur, ou simplement gérer les droits via `role` dans `community_users`. Par exemple, un champ `role` dans `community_users` peut indiquer « admin de communauté », « membre » ou « modérateur ».  

En somme, on enrichit le modèle existant avec des clés étrangères vers `communities` et des champs spécifiques (`max_participants`, `is_global`, `referral_code`, etc.) sans changer radicalement la structure de base. 

## Relations entre entités

Le modèle conceptuel est le suivant :

- Un **utilisateur** peut appartenir à plusieurs communautés (relation *many-to-many* via `community_users`). Chaque communauté a des admins (utilisateurs avec rôle d’admin).  
- Un **service/annonce** est créé par un utilisateur (clé `user_id`). Il peut appartenir à une communauté locale (via `community_id` ou pivot). Si l’utilisateur coche « publier globalement », alors le service est aussi associé au site global (on peut modéliser cela par un enregistrement avec `community_id = NULL` ou via le pivot mentionné).  
- Un service peut accueillir plusieurs **participants** : la relation `service_participants` lie n’importe quel utilisateur (participant) à un service. Cela transforme le service en événement collectif. Le champ `max_participants` dans la table des services fixe la capacité.  
- Le **parrainage** : un utilisateur *P* peut parrainer un utilisateur *F*. Si *F* s’inscrit avec le code de *P*, on enregistre (`referrals`) : `(P, F)`. On peut rendre cela réciproque avec champs dans `users` ou via la table dédiée.  
- **Paiement** : la table `payment_configs` est liée à `communities`. Chaque transaction (table `payments`, si on la crée) référencera la config utilisée et la communauté ou l’utilisateur.  

Ces relations assurent l’**isolation** des données. Par défaut, un utilisateur voit essentiellement les services de *ses* communautés (et ceux du site global s’il y est abonné)【62†L77-L86】【62†L106-L115】. La plateforme devra imposer des filtres dans les requêtes : p.ex. `WHERE community_id = X OR is_global = true`.  

## Architecture technique : priorités vs fonctionnalités différées

**À mettre en place en priorité (architecture)** :
- **Base multi-communautés** : créer la table `communities` et la lier aux utilisateurs et services. Cela constitue le pivot de la structure. C’est la base de « l’espace » pour chaque communauté.  
- **Permissions et rôles** : implémenter les trois niveaux d’admin (global, communauté, utilisateur) en découpant bien qui peut gérer quoi. Par exemple, un admin de communauté ne doit agir que sur `community_id = X`.  
- **Isolation des données** : décider la stratégie (voir paragraphe suivant). L’architecture doit d’abord garantir que les données d’une communauté fermée sont séparées. C’est fondamental.  
- **Parrainage** : ajouter les champs ou table `referrals` dès le début, car c’est simple et cela permet de démarrer le système de récompense.  
- **Services multi-communautés** : permettre qu’une annonce locale soit visible globalement et vice versa (via champ `is_global` ou pivot). Ex. un cours de yoga à Marseille peut être proposé à toute la France.  

**À planifier pour plus tard (fonctionnalités optionnelles)** :
- **Paiement en ligne** : intégrer HelloAsso/Stripe/PayPal peut être initialement déconnecté (stocker seulement `payment_configs`). Les workflows de paiement, paiements réels et abonnements de communauté peuvent venir ensuite.  
- **Monétisation des communautés** : la facturation pour avoir une communauté fermée pourrait être implémentée après coup (système d’abonnements).  
- **API avancée ou interopérabilité** : si besoin, on pourra prévoir une API REST/GraphQL multi‑tenant, mais c’est plus un choix technique secondaire.  
- **Fonctions annexes** : messagerie interne, notifications, recommandations, etc. peuvent être ajoutées après la mise en place du modèle de données.  

La priorité est la **solidité du modèle de données et de la sécurité multi‑tenant**. Les fonctionnalités clés (parrainage, service collaboratif) seront construites sur cette base. 

## Modèle de partition des données (« multitenancy »)

Plusieurs approches existent pour répartir les données des communautés dans la base. Deux options courantes :  

- **Schema partagé avec colonne communautaire** : chaque table de contenu (services, utilisateurs, etc.) contient une colonne `community_id` (ou `OrgID`). On y place l’ID de la communauté propriétaire. Cette solution est simple et efficace en stockage【66†L1-L4】,【72†L1-L4】. Par exemple, Salesforce utilise un champ `OrgID` dans chacune de ses tables partagées, garantissant que chaque enregistrement appartient à un tenant【72†L1-L4】【72†L12-L16】 (voir figure ci‑dessous). L’inconvénient est qu’il faut systématiquement filtrer toutes les requêtes par cette colonne, et le risque d’erreur (ou de fuite de données) existe si on oublie un `WHERE`.  

  【70†embed_image】 *Figure : Exemple de schéma de données multitenant (inspiré de Salesforce). Chaque table centrale (ex. MT_DATA) possède une colonne `OrgID` (tenant) pour isoler les données par organisation【72†L1-L4】【72†L12-L16】.*  

- **Schémas séparés** : chaque communauté a son propre sous‑schéma ou ses propres tables (ex. préfixe `commX_`). Par analogie, WordPress Multisite duplique toutes les tables pour chaque site (ex. `wp_2_posts` pour la communauté d’ID 2)【62†L106-L115】, tout en partageant quelques tables globales (utilisateurs)【62†L77-L86】. On pourrait reproduire cela : avoir une table `services_comm1`, `services_comm2`, etc. C’est isolant, mais plus complexe à gérer en code et en migrations. À l’inverse, un schéma séparé réduit le risque de fuite de données entre communautés【67†L1-L4】,【62†L106-L115】.  

- **Base séparée** : chaque communauté sur sa propre base de données. Hautement isolé mais coûteux en maintenance. Probablement excessif pour Entraide.  

Dans notre cas, l’approche la plus simple est **partagée avec identifiant de communauté**【66†L1-L4】. On stocke toutes les données dans une base commune et on filtre par `community_id`. Par exemple, la table `MT_DATA` de Salesforce montre que chaque ligne a un `OrgID` (tenant)【72†L12-L16】. De même, on ajoutera dans `services`, `users`, etc. une colonne pour l’ID de communauté. Les données du site global peuvent être traitées comme une communauté spéciale (par exemple `community_id = NULL` ou valeur nulle) ou comme un ID dédié (comm_id = 0).  

【71†embed_image】 *Figure : Exemple simplifié de lignes de données multi‑tenant. Chaque enregistrement (ligne) possède un champ `OrgID` (ici “org1”) indiquant son tenant/communauté, avec une clé GUID. Ce motif est équivalent à ajouter `community_id` dans chaque table partagée【72†L12-L16】【66†L1-L4】.*  

Cette solution est moins coûteuse à déployer qu’un schéma séparé et permet par exemple d’offrir aux utilisateurs de découvrir facilement les annonces d’autres communautés si la communauté est ouverte. En revanche, il faut être vigilant sur les permissions et requêtes (toujours filtrer sur `community_id`). 

## Concurrents et inspirations

Sur le web, plusieurs projets illustrent ce concept de plateforme d’entraide multicommunautés ou de mutualisation de ressources :

- **Communo (France)** : c’est une plateforme open‑source de mutualisation locale lancée en Loire-Atlantique. Communo permet aux habitants de créer ou rejoindre des « cercles » (famille, collègues, associations) pour partager du matériel et de l’aide【9†L66-L72】【9†L75-L83】. Chaque cercle agit comme une mini‑communauté solidaire. Ce modèle de « cercles » est inspirant pour gérer des groupes de proximité.  
- **Mobilizon (Framasoft)** : bien qu’axé « événements/meet-ups », Mobilizon est un logiciel libre où les utilisateurs peuvent créer plusieurs **groupes (collectifs)** et publier des événements. Il sert d’alternative aux plateformes centralisées (Facebook, Meetup, EventBrite)【61†L163-L170】【61†L178-L183】. La notion d’adhésion à des groupes et de partage d’événements est intéressante : on y voit la communauté comme un réseau de groupes interconnectés.  
- **Plateformes municipales** : la ville de Marseille avec « Entraidons-nous » ou d’autres collectivités offrent des sites d’entraide locale (souvent gratuits et ciblés)【58†L1436-L1443】. Elles montrent le besoin fort d’entraide locale structurée. Entraide pourrait donc se positionner face à ces initiatives publiques en offrant une solution personnalisable pour chaque ville ou association.  
- **WordPress Multisite** : c’est le modèle de référence mentionné dans la vision. WordPress crée un préfixe de tables par site (ex. `wp_3_posts`) pour isoler le contenu【62†L106-L115】, tout en partageant les utilisateurs globaux【62†L77-L86】. Notre plateforme reprendra l’idée générale (un utilisateur / sera global, un contenu / peut être local), mais on la simplifiera dans un même schéma de BD.  

Aucune plateforme libre spécialisée « entraide locale multi-communautés » n’est majeure sur le marché, donc Entraide aura une belle place (à condition d’être facile à utiliser). Des concurrents potentiels : outils plus génériques comme HumHub (réseau social open-source modulaire) ou Diaspora, voire des solutions propriétaires (Mighty Networks, Circle). Mais Entraide se différencie par sa focalisation territoriale, son intégration possible avec HelloAsso (très utilisé en France) et son système de parrainage/récompense. 

## Points de vigilance et risques techniques

- **Isolation des données** : la principale difficulté est de ne jamais mélanger les annonces des communautés fermées. Il faut imposer des filtres rigoureux (`community_id = X`). Toute requête SQL ou ORM doit inclure la restriction de communauté, sinon les données fuitent. On peut envisager une solution de « row-level security » (PostgreSQL) ou un middleware applicatif systématique.  
- **Performance multi-tenant** : avec de nombreuses communautés, les tables partagées peuvent devenir volumineuses. Il faut indexer les colonnes `community_id` et prévoir la pagination/filtrage efficace. Au besoin, on envisagera du sharding (diviser la base par groupes de communautés) ou du caching. Salesforce, par exemple, partitionne physiquement par OrgID pour optimiser【72†L19-L22】.  
- **Gestion des sous-domaines** : le routage HTTP doit reconnaître chaque sous-domaine de communauté. Cela implique une configuration DNS et certificats SSL dynamiques (Let's Encrypt automatisé) pour *X*.technique. Il faut aussi prévoir la gestion du site global (entraide.fr) comme cas spécial.  
- **Écriture simultanée / Concurrence** : si un service est publié à la fois globalement et localement, éviter les doublons et gérer correctement l’unicité (par exemple, en évitant de dupliquer le même enregistrement deux fois). On peut résoudre avec une pivot table unique ou des flags plutôt qu’avec deux enregistrements quasi‑identiques.  
- **Évolutions de schéma** : comme dans tout gros projet, modifier les tables existantes doit être fait prudemment (migrations). Ajouter des colonnes est simple, mais si à l’avenir on passe à des architectures plus complexes (ex. microservices ou bases séparées), prévoir des ponts ou transformations.  
- **Sécurité / modération** : un réseau ouvert risque spam et contenus inappropriés. Prévoir des outils de modération par communauté (modérateurs désignés, signalements). De même, le système de parrainage doit prévenir la fraude (plusieurs comptes liés entre eux).  
- **Intégration de paiement** : stocker les clefs API (Stripe etc.) exige de la sécurité (ne pas exposer dans le code client). Penser chiffrement des configs sensibles. S’assurer aussi qu’un site global restreint (HelloAsso) se couplera bien avec les communautés (ex. versement aux bonnes entités).  
- **Évolutions futures** : à l’avenir, on pourrait introduire du multi-langue (i18n) si on vise plusieurs pays, ou des flux de données fédérés entre communautés. Il faut laisser de la flexibilité dans le modèle (par ex. champ `settings` JSON) pour ajouter de telles options.  

En résumé, l’architecture doit être robuste et simple à maintenir. On recommandera de commencer par un schéma partagé avec clé de communauté (solution la plus agile), puis éventuellement migrer certaines communautés critiques vers des schémas séparés si la charge explose. L’essentiel est d’établir d’emblée la structure des tables et relations décrites ici. 

## Conclusion

Cette proposition pose un **modèle de données multi‑communautés** clair : une table `communities` pour isoler chaque réseau local, des liens explicites (pivots) entre utilisateurs, services et communautés, et des champs dédiés pour les fonctionnalités clés (parrainage, cours collectifs, paiement). Nous avons pris exemple sur des architectures éprouvées (WordPress Multisite, Salesforce) et observé les initiatives existantes (Communo, Mobilizon, etc.) pour inspirer des idées innovantes. Par exemple, le système de *cercles* de Communo ou la gestion d’événements de Mobilizon montrent l’intérêt de structures flexibles. Entraide deviendra ainsi une plateforme **modulaire et tournée vers l’avenir**, capable de fédérer de nombreuses communautés locales avec les outils modernes (récompenses, sous-domaines, paiements intégrés). 

